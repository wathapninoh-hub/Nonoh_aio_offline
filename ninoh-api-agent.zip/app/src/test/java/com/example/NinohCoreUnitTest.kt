package com.example

import com.example.data.network.UrlNormalizer
import com.example.domain.ContentSegment
import com.example.domain.MarkdownParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NinohCoreUnitTest {

    @Test
    fun `url normalizer strips trailing slashes and completions path`() {
        val res = UrlNormalizer.validateAndNormalizeBaseUrl("https://openrouter.ai/api/v1/chat/completions/")
        assertTrue(res is UrlNormalizer.ValidationResult.Valid)
        val valid = res as UrlNormalizer.ValidationResult.Valid
        assertEquals("https://openrouter.ai/api/v1", valid.normalizedBaseUrl)
        assertEquals("https://openrouter.ai/api/v1/models", UrlNormalizer.buildModelsUrl(valid.normalizedBaseUrl))
        assertEquals("https://openrouter.ai/api/v1/chat/completions", UrlNormalizer.buildChatCompletionsUrl(valid.normalizedBaseUrl))
    }

    @Test
    fun `url normalizer rejects non http schemes and remote cleartext`() {
        val jsScheme = UrlNormalizer.validateAndNormalizeBaseUrl("javascript:alert(1)")
        assertTrue(jsScheme is UrlNormalizer.ValidationResult.Invalid)

        val remoteHttp = UrlNormalizer.validateAndNormalizeBaseUrl("http://api.example.com/v1")
        assertTrue(remoteHttp is UrlNormalizer.ValidationResult.Invalid)

        val localHttp = UrlNormalizer.validateAndNormalizeBaseUrl("http://10.0.2.2:11434/v1")
        assertTrue(localHttp is UrlNormalizer.ValidationResult.Valid)
    }

    @Test
    fun `markdown parser extracts prose and multiple fenced code blocks`() {
        val md = """
            Here is your Kotlin snippet:
            ```kotlin
            fun greet() = println("Hello NINOH")
            ```
            And HTML:
            ```html
            <h1>Hi</h1>
            ```
        """.trimIndent()

        val segments = MarkdownParser.parseSegments(md)
        assertEquals(4, segments.size)
        assertTrue(segments[0] is ContentSegment.Text)
        val kotlinBlock = segments[1] as ContentSegment.CodeBlock
        assertEquals("kotlin", kotlinBlock.language)
        assertTrue(kotlinBlock.code.contains("Hello NINOH"))
        val htmlBlock = segments[3] as ContentSegment.CodeBlock
        assertEquals("html", htmlBlock.language)

        val extracted = MarkdownParser.extractAllCode(md)
        assertTrue(extracted.contains("fun greet()"))
        assertTrue(extracted.contains("<h1>Hi</h1>"))
    }
}
