package com.example.domain

enum class CodingLanguage(val label: String, val fenceTag: String) {
    HTML("HTML", "html"),
    CSS("CSS", "css"),
    JAVASCRIPT("JavaScript", "javascript"),
    PYTHON("Python", "python"),
    JAVA("Java", "java"),
    KOTLIN("Kotlin", "kotlin"),
    CPP("C++", "cpp"),
    TYPESCRIPT("TypeScript", "typescript"),
    SQL("SQL", "sql"),
    RUST("Rust", "rust"),
    GO("Go", "go"),
    OTHER("Other", "text")
}

enum class CodingTaskMode(val label: String, val instruction: String) {
    GENERATE("Generate", "Write clean, complete, production-ready code solving the task."),
    DEBUG("Debug & Fix", "Identify bugs, edge cases, or crashes and provide the corrected code."),
    REFACTOR("Refactor", "Improve structure, readability, performance, and maintainability."),
    EXPLAIN("Explain", "Explain the code clearly step by step and highlight key logic."),
    TESTS("Unit Tests", "Write comprehensive unit tests covering normal and edge cases.")
}

object CodingPrompts {

    fun buildSystemPrompt(language: CodingLanguage, mode: CodingTaskMode): String {
        return """
            You are NINOH API AGENT in Dedicated Coding Assistant mode.
            Primary Target Language: ${language.label}
            Task Mode: ${mode.label} — ${mode.instruction}

            Rules:
            - Always format code inside fenced markdown blocks with the language tag (```${language.fenceTag}).
            - Provide complete, runnable, idiomatic code without placeholder TODOs.
            - Keep explanations concise, accurate, and technical.
        """.trimIndent()
    }

    fun buildUserMessage(
        language: CodingLanguage,
        mode: CodingTaskMode,
        prompt: String,
        sourceCode: String
    ): String {
        val sb = StringBuilder()
        sb.append("[Language: ${language.label} | Mode: ${mode.label}]\n")
        sb.append(prompt.trim())
        if (sourceCode.isNotBlank()) {
            sb.append("\n\nReference / Existing Code:\n```${language.fenceTag}\n")
            sb.append(sourceCode.trim())
            sb.append("\n```")
        }
        return sb.toString()
    }
}
