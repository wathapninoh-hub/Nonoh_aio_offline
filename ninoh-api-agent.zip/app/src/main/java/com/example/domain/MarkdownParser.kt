package com.example.domain

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import com.example.ui.theme.CodeComment
import com.example.ui.theme.CodeKeyword
import com.example.ui.theme.CodeNumber
import com.example.ui.theme.CodeString
import com.example.ui.theme.CodeType
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.TextPrimary

sealed class ContentSegment {
    data class Text(val markdown: String) : ContentSegment()
    data class CodeBlock(val language: String, val code: String, val isClosed: Boolean) : ContentSegment()
}

object MarkdownParser {

    fun parseSegments(input: String): List<ContentSegment> {
        if (input.isEmpty()) return emptyList()

        val segments = mutableListOf<ContentSegment>()
        val lines = input.lines()
        val textBuffer = StringBuilder()
        val codeBuffer = StringBuilder()
        var inCodeBlock = false
        var currentLang = ""

        for (line in lines) {
            val trimmed = line.trimStart()
            if (!inCodeBlock) {
                if (trimmed.startsWith("```")) {
                    val flushedText = textBuffer.toString().trim()
                    if (flushedText.isNotEmpty()) {
                        segments.add(ContentSegment.Text(flushedText))
                    }
                    textBuffer.clear()
                    currentLang = trimmed.removePrefix("```").trim().ifEmpty { "code" }
                    inCodeBlock = true
                } else {
                    if (textBuffer.isNotEmpty()) textBuffer.append('\n')
                    textBuffer.append(line)
                }
            } else {
                if (trimmed.startsWith("```")) {
                    segments.add(
                        ContentSegment.CodeBlock(
                            language = currentLang,
                            code = codeBuffer.toString().trimEnd(),
                            isClosed = true
                        )
                    )
                    codeBuffer.clear()
                    currentLang = ""
                    inCodeBlock = false
                } else {
                    if (codeBuffer.isNotEmpty()) codeBuffer.append('\n')
                    codeBuffer.append(line)
                }
            }
        }

        if (inCodeBlock) {
            segments.add(
                ContentSegment.CodeBlock(
                    language = currentLang,
                    code = codeBuffer.toString(),
                    isClosed = false
                )
            )
        } else {
            val remaining = textBuffer.toString().trim()
            if (remaining.isNotEmpty()) {
                segments.add(ContentSegment.Text(remaining))
            }
        }

        return segments
    }

    fun extractAllCode(input: String): String {
        val codeBlocks = parseSegments(input)
            .filterIsInstance<ContentSegment.CodeBlock>()
            .map { it.code }
            .filter { it.isNotBlank() }
        return if (codeBlocks.isNotEmpty()) {
            codeBlocks.joinToString("\n\n")
        } else {
            input
        }
    }

    fun formatInlineMarkdown(text: String, codeFont: FontFamily): AnnotatedString {
        return buildAnnotatedString {
            var i = 0
            while (i < text.length) {
                when {
                    text.startsWith("**", i) -> {
                        val end = text.indexOf("**", i + 2)
                        if (end != -1) {
                            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = TextPrimary)) {
                                append(text.substring(i + 2, end))
                            }
                            i = end + 2
                        } else {
                            append(text[i])
                            i++
                        }
                    }
                    text[i] == '`' -> {
                        val end = text.indexOf('`', i + 1)
                        if (end != -1) {
                            withStyle(
                                SpanStyle(
                                    fontFamily = codeFont,
                                    color = CyanElectric,
                                    background = Color(0xFF142138)
                                )
                            ) {
                                append(" ${text.substring(i + 1, end)} ")
                            }
                            i = end + 1
                        } else {
                            append(text[i])
                            i++
                        }
                    }
                    else -> {
                        append(text[i])
                        i++
                    }
                }
            }
        }
    }

    private val KEYWORDS = setOf(
        "fun", "val", "var", "class", "interface", "object", "data", "sealed", "enum",
        "return", "if", "else", "when", "for", "while", "do", "try", "catch", "finally",
        "import", "package", "private", "public", "protected", "internal", "override",
        "suspend", "async", "await", "function", "const", "let", "export", "default",
        "def", "lambda", "yield", "from", "as", "with", "pass", "break", "continue",
        "struct", "impl", "fn", "mut", "pub", "use", "mod", "switch", "case", "throw",
        "new", "this", "super", "extends", "implements", "void", "int", "float", "double",
        "boolean", "bool", "char", "true", "false", "null", "None", "True", "False",
        "SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE", "DELETE",
        "CREATE", "TABLE", "JOIN", "ON", "ORDER", "BY", "GROUP", "LIMIT", "include", "using", "namespace"
    )

    fun highlightCode(code: String): AnnotatedString {
        return buildAnnotatedString {
            val lines = code.split('\n')
            lines.forEachIndexed { lineIdx, line ->
                val trimmed = line.trimStart()
                if (trimmed.startsWith("//") || trimmed.startsWith("#") || trimmed.startsWith("--") || trimmed.startsWith("/*") || trimmed.startsWith("*")) {
                    withStyle(SpanStyle(color = CodeComment)) {
                        append(line)
                    }
                } else {
                    tokenizeLine(line)
                }
                if (lineIdx < lines.lastIndex) {
                    append('\n')
                }
            }
        }
    }

    private fun AnnotatedString.Builder.tokenizeLine(line: String) {
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '/' && i + 1 < line.length && line[i + 1] == '/' -> {
                    withStyle(SpanStyle(color = CodeComment)) {
                        append(line.substring(i))
                    }
                    return
                }
                ch == '"' || ch == '\'' || ch == '`' -> {
                    val quote = ch
                    var j = i + 1
                    while (j < line.length) {
                        if (line[j] == '\\' && j + 1 < line.length) {
                            j += 2
                            continue
                        }
                        if (line[j] == quote) {
                            j++
                            break
                        }
                        j++
                    }
                    withStyle(SpanStyle(color = CodeString)) {
                        append(line.substring(i, j))
                    }
                    i = j
                }
                ch.isDigit() && (i == 0 || !line[i - 1].isLetterOrDigit()) -> {
                    var j = i
                    while (j < line.length && (line[j].isDigit() || line[j] == '.' || line[j] == 'x' || line[j] in 'a'..'f' || line[j] in 'A'..'F')) {
                        j++
                    }
                    withStyle(SpanStyle(color = CodeNumber)) {
                        append(line.substring(i, j))
                    }
                    i = j
                }
                ch.isLetter() || ch == '_' || ch == '<' -> {
                    if (ch == '<') {
                        val endTag = line.indexOf('>', i + 1)
                        if (endTag != -1 && endTag - i < 32 && !line.substring(i + 1, endTag).contains(' ')) {
                            withStyle(SpanStyle(color = CodeKeyword)) {
                                append(line.substring(i, endTag + 1))
                            }
                            i = endTag + 1
                            continue
                        }
                    }
                    var j = i
                    while (j < line.length && (line[j].isLetterOrDigit() || line[j] == '_')) {
                        j++
                    }
                    val word = line.substring(i, j)
                    when {
                        word in KEYWORDS -> withStyle(SpanStyle(color = CodeKeyword, fontWeight = FontWeight.Medium)) {
                            append(word)
                        }
                        word.firstOrNull()?.isUpperCase() == true -> withStyle(SpanStyle(color = CodeType)) {
                            append(word)
                        }
                        else -> append(word)
                    }
                    i = j.coerceAtLeast(i + 1)
                }
                else -> {
                    append(ch)
                    i++
                }
            }
        }
    }
}
