package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AgentSettings
import com.example.data.local.CachedModelEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.ConversationMode
import com.example.data.local.MessageEntity
import com.example.data.local.ProviderEntity
import com.example.data.local.ProviderPreset
import com.example.data.network.ChatMessageDto
import com.example.data.network.ConnectionTestResult
import com.example.data.network.StreamEvent
import com.example.data.network.UrlNormalizer
import com.example.data.repository.NinohRepository
import com.example.domain.CodingLanguage
import com.example.domain.CodingPrompts
import com.example.domain.CodingTaskMode
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class ProviderUiItem(
    val entity: ProviderEntity,
    val hasApiKey: Boolean,
    val maskedKey: String
)

data class ApiSettingsFeedback(
    val isError: Boolean,
    val message: String,
    val latencyMs: Long? = null
)

data class MainUiState(
    val providers: List<ProviderUiItem> = emptyList(),
    val activeProvider: ProviderUiItem? = null,
    val settings: AgentSettings = AgentSettings(),
    val conversations: List<ConversationEntity> = emptyList(),
    val activeConversationId: String? = null,
    val activeCodingConversationId: String? = null,
    val modelsForActiveProvider: List<CachedModelEntity> = emptyList(),
    val isStreamingChat: Boolean = false,
    val isStreamingCoding: Boolean = false,
    val isFetchingModels: Boolean = false,
    val isTestingConnection: Boolean = false,
    val modelsError: String? = null,
    val apiFeedback: ApiSettingsFeedback? = null,
    val selectedCodingLanguage: CodingLanguage = CodingLanguage.KOTLIN,
    val selectedCodingMode: CodingTaskMode = CodingTaskMode.GENERATE
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository = NinohRepository(application)

    private val _activeChatConversationId = MutableStateFlow<String?>(null)
    private val _activeCodingConversationId = MutableStateFlow<String?>(null)
    private val _isStreamingChat = MutableStateFlow(false)
    private val _isStreamingCoding = MutableStateFlow(false)
    private val _isFetchingModels = MutableStateFlow(false)
    private val _isTestingConnection = MutableStateFlow(false)
    private val _modelsError = MutableStateFlow<String?>(null)
    private val _apiFeedback = MutableStateFlow<ApiSettingsFeedback?>(null)
    private val _selectedCodingLanguage = MutableStateFlow(CodingLanguage.KOTLIN)
    private val _selectedCodingMode = MutableStateFlow(CodingTaskMode.GENERATE)
    private val _credentialsRefreshTick = MutableStateFlow(0)

    private var chatJob: Job? = null
    private var codingJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureDefaultPresetsSeeded()
        }
    }

    private val providersUiFlow = combine(
        repository.providersFlow,
        _credentialsRefreshTick
    ) { providers, _ ->
        providers.map { entity ->
            ProviderUiItem(
                entity = entity,
                hasApiKey = repository.hasApiKey(entity.id),
                maskedKey = repository.getMaskedApiKey(entity.id)
            )
        }
    }

    private val activeProviderModelsFlow = repository.settingsFlow.flatMapLatest { settings ->
        repository.observeModelsForProvider(settings.activeProviderId)
    }

    val chatMessages: StateFlow<List<MessageEntity>> = _activeChatConversationId.flatMapLatest { convId ->
        if (convId == null) flowOf(emptyList()) else repository.observeMessages(convId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val codingMessages: StateFlow<List<MessageEntity>> = _activeCodingConversationId.flatMapLatest { convId ->
        if (convId == null) flowOf(emptyList()) else repository.observeMessages(convId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val baseDataFlow = combine(
        providersUiFlow,
        repository.settingsFlow,
        repository.conversationsFlow,
        activeProviderModelsFlow
    ) { providers, settings, conversations, models ->
        BaseSnapshot(providers, settings, conversations, models)
    }

    private val sessionIdsFlow = combine(
        _activeChatConversationId,
        _activeCodingConversationId,
        _selectedCodingLanguage,
        _selectedCodingMode
    ) { chatId, codingId, lang, mode ->
        SessionSnapshot(chatId, codingId, lang, mode)
    }

    private val statusFlagsFlow = combine(
        _isStreamingChat,
        _isStreamingCoding,
        _isFetchingModels,
        _isTestingConnection,
        _modelsError,
        _apiFeedback
    ) { arr ->
        StatusSnapshot(
            isStreamingChat = arr[0] as Boolean,
            isStreamingCoding = arr[1] as Boolean,
            isFetchingModels = arr[2] as Boolean,
            isTestingConnection = arr[3] as Boolean,
            modelsError = arr[4] as String?,
            apiFeedback = arr[5] as ApiSettingsFeedback?
        )
    }

    val uiState: StateFlow<MainUiState> = combine(
        baseDataFlow,
        sessionIdsFlow,
        statusFlagsFlow
    ) { base, session, status ->
        val activeProvider = base.providers.find { it.entity.id == base.settings.activeProviderId }
            ?: base.providers.firstOrNull()
        MainUiState(
            providers = base.providers,
            activeProvider = activeProvider,
            settings = base.settings,
            conversations = base.conversations,
            activeConversationId = session.chatId,
            activeCodingConversationId = session.codingId,
            modelsForActiveProvider = base.models,
            isStreamingChat = status.isStreamingChat,
            isStreamingCoding = status.isStreamingCoding,
            isFetchingModels = status.isFetchingModels,
            isTestingConnection = status.isTestingConnection,
            modelsError = status.modelsError,
            apiFeedback = status.apiFeedback,
            selectedCodingLanguage = session.lang,
            selectedCodingMode = session.mode
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MainUiState())

    fun startNewChat() {
        chatJob?.cancel()
        _isStreamingChat.value = false
        _activeChatConversationId.value = null
    }

    fun startNewCodingSession() {
        codingJob?.cancel()
        _isStreamingCoding.value = false
        _activeCodingConversationId.value = null
    }

    fun openConversation(conversation: ConversationEntity) {
        if (conversation.mode == ConversationMode.CODING.name) {
            _activeCodingConversationId.value = conversation.id
            CodingLanguage.entries.find { it.label == conversation.language }?.let {
                _selectedCodingLanguage.value = it
            }
        } else {
            _activeChatConversationId.value = conversation.id
        }
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameConversation(conversationId, newTitle)
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            if (_activeChatConversationId.value == conversationId) {
                startNewChat()
            }
            if (_activeCodingConversationId.value == conversationId) {
                startNewCodingSession()
            }
            repository.deleteConversation(conversationId)
        }
    }

    fun setCodingLanguage(language: CodingLanguage) {
        _selectedCodingLanguage.value = language
    }

    fun setCodingMode(mode: CodingTaskMode) {
        _selectedCodingMode.value = mode
    }

    fun sendChatMessage(promptText: String) {
        val cleanPrompt = promptText.trim()
        if (cleanPrompt.isEmpty() || _isStreamingChat.value) return

        val state = uiState.value
        val providerItem = state.activeProvider
        if (providerItem == null) {
            return
        }

        val modelId = state.settings.activeModelId.ifBlank { providerItem.entity.defaultModelId }

        chatJob?.cancel()
        chatJob = viewModelScope.launch {
            val now = System.currentTimeMillis()
            val convId = _activeChatConversationId.value ?: run {
                val title = cleanPrompt.take(44).let { if (cleanPrompt.length > 44) "$it…" else it }
                val created = repository.createConversation(
                    title = title,
                    mode = ConversationMode.CHAT,
                    providerId = providerItem.entity.id,
                    modelId = modelId
                )
                _activeChatConversationId.value = created.id
                created.id
            }

            val userMsg = MessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = convId,
                role = "user",
                content = cleanPrompt,
                timestamp = now
            )
            repository.addMessage(userMsg)

            if (!providerItem.hasApiKey) {
                repository.addMessage(
                    MessageEntity(
                        id = UUID.randomUUID().toString(),
                        conversationId = convId,
                        role = "assistant",
                        content = "No API key is saved for ${providerItem.entity.name}. Open API Settings to add your API key and test the connection.",
                        providerName = providerItem.entity.name,
                        modelId = modelId,
                        isError = true,
                        timestamp = now + 1
                    )
                )
                return@launch
            }

            val history = repository.getConversationMessagesOnce(convId)
                .filter { !it.isError }
                .takeLast(20)
                .map { ChatMessageDto(role = it.role, content = it.content) }

            val requestMessages = buildList {
                add(ChatMessageDto(role = "system", content = state.settings.customSystemPrompt))
                addAll(history)
            }

            val assistantMsgId = UUID.randomUUID().toString()
            repository.addMessage(
                MessageEntity(
                    id = assistantMsgId,
                    conversationId = convId,
                    role = "assistant",
                    content = "",
                    providerName = providerItem.entity.name,
                    modelId = modelId,
                    isError = false,
                    timestamp = System.currentTimeMillis()
                )
            )

            _isStreamingChat.value = true
            val buffer = StringBuilder()
            try {
                repository.streamCompletion(
                    provider = providerItem.entity,
                    modelId = modelId,
                    messages = requestMessages,
                    temperature = state.settings.temperature,
                    maxTokens = state.settings.maxTokens,
                    stream = state.settings.streamResponses
                ).collect { event ->
                    when (event) {
                        is StreamEvent.Delta -> {
                            buffer.append(event.chunk)
                            repository.updateMessageContent(assistantMsgId, buffer.toString(), isError = false)
                        }
                        is StreamEvent.Completed -> {
                            repository.updateMessageContent(
                                messageId = assistantMsgId,
                                content = event.fullContent,
                                isError = false,
                                latencyMs = event.latencyMs
                            )
                        }
                        is StreamEvent.Error -> {
                            val prefix = if (buffer.isNotEmpty()) "${buffer}\n\n" else ""
                            repository.updateMessageContent(
                                messageId = assistantMsgId,
                                content = "$prefix${event.message}",
                                isError = true
                            )
                        }
                    }
                }
            } finally {
                _isStreamingChat.value = false
            }
        }
    }

    fun stopChatGeneration() {
        chatJob?.cancel()
        _isStreamingChat.value = false
    }

    fun sendCodingRequest(promptText: String, sourceCode: String) {
        val cleanPrompt = promptText.trim()
        if ((cleanPrompt.isEmpty() && sourceCode.isBlank()) || _isStreamingCoding.value) return

        val state = uiState.value
        val providerItem = state.activeProvider ?: return
        val modelId = state.settings.activeModelId.ifBlank { providerItem.entity.defaultModelId }
        val lang = state.selectedCodingLanguage
        val mode = state.selectedCodingMode

        val effectivePrompt = cleanPrompt.ifEmpty {
            "${mode.label} this ${lang.label} code."
        }
        val formattedUserMsg = CodingPrompts.buildUserMessage(
            language = lang,
            mode = mode,
            prompt = effectivePrompt,
            sourceCode = sourceCode
        )

        codingJob?.cancel()
        codingJob = viewModelScope.launch {
            val now = System.currentTimeMillis()
            val convId = _activeCodingConversationId.value ?: run {
                val title = "${lang.label}: ${effectivePrompt.take(34)}"
                val created = repository.createConversation(
                    title = title,
                    mode = ConversationMode.CODING,
                    language = lang.label,
                    providerId = providerItem.entity.id,
                    modelId = modelId
                )
                _activeCodingConversationId.value = created.id
                created.id
            }

            repository.addMessage(
                MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = "user",
                    content = formattedUserMsg,
                    codeLanguage = lang.label,
                    timestamp = now
                )
            )

            if (!providerItem.hasApiKey) {
                repository.addMessage(
                    MessageEntity(
                        id = UUID.randomUUID().toString(),
                        conversationId = convId,
                        role = "assistant",
                        content = "No API key is saved for ${providerItem.entity.name}. Open API Settings to configure your API key.",
                        providerName = providerItem.entity.name,
                        modelId = modelId,
                        codeLanguage = lang.label,
                        isError = true,
                        timestamp = now + 1
                    )
                )
                return@launch
            }

            val history = repository.getConversationMessagesOnce(convId)
                .filter { !it.isError }
                .takeLast(12)
                .map { ChatMessageDto(role = it.role, content = it.content) }

            val requestMessages = buildList {
                add(ChatMessageDto(role = "system", content = CodingPrompts.buildSystemPrompt(lang, mode)))
                addAll(history)
            }

            val assistantMsgId = UUID.randomUUID().toString()
            repository.addMessage(
                MessageEntity(
                    id = assistantMsgId,
                    conversationId = convId,
                    role = "assistant",
                    content = "",
                    providerName = providerItem.entity.name,
                    modelId = modelId,
                    codeLanguage = lang.label,
                    isError = false,
                    timestamp = System.currentTimeMillis()
                )
            )

            _isStreamingCoding.value = true
            val buffer = StringBuilder()
            try {
                repository.streamCompletion(
                    provider = providerItem.entity,
                    modelId = modelId,
                    messages = requestMessages,
                    temperature = state.settings.temperature.coerceAtMost(0.6f),
                    maxTokens = state.settings.maxTokens,
                    stream = state.settings.streamResponses
                ).collect { event ->
                    when (event) {
                        is StreamEvent.Delta -> {
                            buffer.append(event.chunk)
                            repository.updateMessageContent(assistantMsgId, buffer.toString(), isError = false)
                        }
                        is StreamEvent.Completed -> {
                            repository.updateMessageContent(
                                messageId = assistantMsgId,
                                content = event.fullContent,
                                isError = false,
                                latencyMs = event.latencyMs
                            )
                        }
                        is StreamEvent.Error -> {
                            val prefix = if (buffer.isNotEmpty()) "${buffer}\n\n" else ""
                            repository.updateMessageContent(
                                messageId = assistantMsgId,
                                content = "$prefix${event.message}",
                                isError = true
                            )
                        }
                    }
                }
            } finally {
                _isStreamingCoding.value = false
            }
        }
    }

    fun stopCodingGeneration() {
        codingJob?.cancel()
        _isStreamingCoding.value = false
    }

    fun selectProvider(provider: ProviderEntity) {
        viewModelScope.launch {
            repository.selectActiveProvider(provider)
            _modelsError.value = null
        }
    }

    fun selectModel(modelId: String) {
        val clean = modelId.trim()
        if (clean.isEmpty()) return
        val providerId = uiState.value.activeProvider?.entity?.id ?: return
        viewModelScope.launch {
            repository.selectActiveModel(providerId, clean)
            _activeChatConversationId.value?.let { convId ->
                repository.updateConversationModel(convId, providerId, clean)
            }
            _activeCodingConversationId.value?.let { convId ->
                repository.updateConversationModel(convId, providerId, clean)
            }
        }
    }

    fun fetchModels() {
        val provider = uiState.value.activeProvider?.entity ?: return
        if (_isFetchingModels.value) return
        viewModelScope.launch {
            _isFetchingModels.value = true
            _modelsError.value = null
            val result = repository.fetchModelsForProvider(provider)
            result.onSuccess { list ->
                if (list.isEmpty()) {
                    _modelsError.value = "${provider.name} returned 0 models. You can still enter any Model ID manually."
                }
            }.onFailure { err ->
                _modelsError.value = err.message ?: "Failed to fetch models from ${provider.name}."
            }
            _isFetchingModels.value = false
        }
    }

    fun getRawApiKey(providerId: String): String = repository.getApiKey(providerId)

    fun saveProviderConfig(
        providerId: String?,
        name: String,
        baseUrl: String,
        apiKeyInput: String,
        defaultModelId: String,
        presetType: String,
        keepExistingKeyIfBlank: Boolean
    ) {
        val cleanName = name.trim()
        val cleanModel = defaultModelId.trim()
        if (cleanName.isEmpty()) {
            _apiFeedback.value = ApiSettingsFeedback(true, "Provider name cannot be empty.")
            return
        }
        val urlCheck = UrlNormalizer.validateAndNormalizeBaseUrl(baseUrl)
        if (urlCheck is UrlNormalizer.ValidationResult.Invalid) {
            _apiFeedback.value = ApiSettingsFeedback(true, urlCheck.reason)
            return
        }
        val normalizedUrl = (urlCheck as UrlNormalizer.ValidationResult.Valid).normalizedBaseUrl
        if (cleanModel.isEmpty()) {
            _apiFeedback.value = ApiSettingsFeedback(true, "Default Model ID cannot be empty.")
            return
        }

        val targetId = providerId ?: "custom_${UUID.randomUUID().toString().take(8)}"
        viewModelScope.launch {
            val existing = repository.providersFlow.let {
                uiState.value.providers.find { p -> p.entity.id == targetId }?.entity
            }
            val entity = ProviderEntity(
                id = targetId,
                name = cleanName,
                baseUrl = normalizedUrl,
                defaultModelId = cleanModel,
                presetType = presetType,
                lastTestSuccess = existing?.lastTestSuccess,
                lastTestMessage = existing?.lastTestMessage,
                lastTestLatencyMs = existing?.lastTestLatencyMs,
                lastTestedAt = existing?.lastTestedAt,
                createdAt = existing?.createdAt ?: System.currentTimeMillis()
            )
            val keyToPersist: String? = when {
                apiKeyInput.isNotBlank() -> apiKeyInput.trim()
                keepExistingKeyIfBlank -> null
                else -> ""
            }
            repository.saveProviderConfig(entity, keyToPersist, setAsActive = true)
            _credentialsRefreshTick.update { it + 1 }
            _apiFeedback.value = ApiSettingsFeedback(
                isError = false,
                message = "Saved $cleanName configuration securely."
            )
        }
    }

    fun testProviderConnection(
        providerId: String?,
        name: String,
        baseUrl: String,
        apiKeyInput: String,
        defaultModelId: String,
        presetType: String
    ) {
        if (_isTestingConnection.value) return
        val urlCheck = UrlNormalizer.validateAndNormalizeBaseUrl(baseUrl)
        if (urlCheck is UrlNormalizer.ValidationResult.Invalid) {
            _apiFeedback.value = ApiSettingsFeedback(true, urlCheck.reason)
            return
        }
        val normalizedUrl = (urlCheck as UrlNormalizer.ValidationResult.Valid).normalizedBaseUrl
        val targetId = providerId ?: "custom_${UUID.randomUUID().toString().take(8)}"

        viewModelScope.launch {
            _isTestingConnection.value = true
            _apiFeedback.value = null

            val existing = uiState.value.providers.find { it.entity.id == targetId }?.entity
            val entity = ProviderEntity(
                id = targetId,
                name = name.trim().ifEmpty { "Provider" },
                baseUrl = normalizedUrl,
                defaultModelId = defaultModelId.trim().ifEmpty { "gpt-4o-mini" },
                presetType = presetType,
                createdAt = existing?.createdAt ?: System.currentTimeMillis()
            )
            // Save first if key provided or provider exists, so test result persists cleanly
            val keyToUse = apiKeyInput.trim().ifEmpty { repository.getApiKey(targetId) }
            if (apiKeyInput.isNotBlank()) {
                repository.saveProviderConfig(entity, apiKeyInput.trim(), setAsActive = true)
                _credentialsRefreshTick.update { it + 1 }
            } else {
                repository.saveProviderConfig(entity, null, setAsActive = true)
            }

            val result: ConnectionTestResult = repository.testProviderConnection(entity, keyToUse)
            _apiFeedback.value = ApiSettingsFeedback(
                isError = !result.success,
                message = result.message,
                latencyMs = result.latencyMs
            )
            _isTestingConnection.value = false
        }
    }

    fun deleteProvider(providerId: String) {
        viewModelScope.launch {
            repository.deleteProvider(providerId)
            _credentialsRefreshTick.update { it + 1 }
            _apiFeedback.value = ApiSettingsFeedback(false, "Provider removed.")
        }
    }

    fun clearApiKey(providerId: String) {
        viewModelScope.launch {
            val existing = uiState.value.providers.find { it.entity.id == providerId }?.entity ?: return@launch
            repository.saveProviderConfig(existing, "", setAsActive = false)
            _credentialsRefreshTick.update { it + 1 }
            _apiFeedback.value = ApiSettingsFeedback(false, "API key cleared for ${existing.name}.")
        }
    }

    fun updateAgentParameters(
        temperature: Float,
        maxTokens: Int,
        streamResponses: Boolean,
        customSystemPrompt: String
    ) {
        viewModelScope.launch {
            repository.updateAgentParameters(temperature, maxTokens, streamResponses, customSystemPrompt)
            _apiFeedback.value = ApiSettingsFeedback(false, "Agent parameters updated.")
        }
    }

    fun clearFeedback() {
        _apiFeedback.value = null
    }

    private data class BaseSnapshot(
        val providers: List<ProviderUiItem>,
        val settings: AgentSettings,
        val conversations: List<ConversationEntity>,
        val models: List<CachedModelEntity>
    )

    private data class SessionSnapshot(
        val chatId: String?,
        val codingId: String?,
        val lang: CodingLanguage,
        val mode: CodingTaskMode
    )

    private data class StatusSnapshot(
        val isStreamingChat: Boolean,
        val isStreamingCoding: Boolean,
        val isFetchingModels: Boolean,
        val isTestingConnection: Boolean,
        val modelsError: String?,
        val apiFeedback: ApiSettingsFeedback?
    )
}
