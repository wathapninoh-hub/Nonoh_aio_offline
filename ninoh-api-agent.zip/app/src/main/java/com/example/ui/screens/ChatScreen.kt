package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.NoApiKeyCalloutCard
import com.example.ui.components.ProviderStatusChip
import com.example.ui.components.RenameConversationDialog
import com.example.ui.components.RichMessageContent
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.DeepPanel
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.VioletPulse
import com.example.viewmodel.MainUiState
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    uiState: MainUiState,
    messages: List<MessageEntity>,
    activeConversation: ConversationEntity?,
    onOpenDrawer: () -> Unit,
    onOpenModelSelector: () -> Unit,
    onOpenApiSettings: () -> Unit,
    onNewChat: () -> Unit,
    onRenameConversation: (String, String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onSendMessage: (String) -> Unit,
    onStopGeneration: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .imePadding()
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepPanel,
                titleContentColor = TextPrimary
            ),
            navigationIcon = {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier.testTag("drawer_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open navigation menu",
                        tint = TextPrimary
                    )
                }
            },
            title = {
                Column(
                    modifier = Modifier.clickable(enabled = activeConversation != null) {
                        showRenameDialog = true
                    }
                ) {
                    Text(
                        text = activeConversation?.title ?: "NINOH Chat",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = uiState.activeProvider?.entity?.name ?: "No Provider",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanElectric,
                        maxLines = 1
                    )
                }
            },
            actions = {
                ProviderStatusChip(
                    providerItem = uiState.activeProvider,
                    modelId = uiState.settings.activeModelId,
                    onClick = onOpenModelSelector
                )
                IconButton(
                    onClick = onNewChat,
                    modifier = Modifier.testTag("new_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddComment,
                        contentDescription = "New Chat",
                        tint = CyanElectric
                    )
                }
                if (activeConversation != null) {
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Conversation actions",
                                tint = TextSecondary
                            )
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Rename Chat") },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    showRenameDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Chat", color = CrimsonAlert) },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.DeleteOutline,
                                        contentDescription = null,
                                        tint = CrimsonAlert
                                    )
                                },
                                onClick = {
                                    showMenu = false
                                    showDeleteDialog = true
                                }
                            )
                        }
                    }
                }
            }
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty()) {
                ChatEmptyState(
                    uiState = uiState,
                    onOpenApiSettings = onOpenApiSettings,
                    onQuickPrompt = { prompt ->
                        if (uiState.activeProvider?.hasApiKey == true) {
                            onSendMessage(prompt)
                        } else {
                            inputText = prompt
                        }
                    }
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    contentPadding = PaddingValues(vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (uiState.activeProvider?.hasApiKey != true) {
                        item(key = "no_key_banner") {
                            NoApiKeyCalloutCard(
                                providerName = uiState.activeProvider?.entity?.name ?: "your provider",
                                onOpenSettings = onOpenApiSettings
                            )
                        }
                    }

                    items(messages, key = { it.id }) { msg ->
                        if (msg.role == "user") {
                            UserMessageBubble(message = msg)
                        } else {
                            val isLast = msg.id == messages.lastOrNull()?.id
                            AssistantMessageCard(
                                message = msg,
                                isStreaming = uiState.isStreamingChat && isLast,
                                onRetry = if (msg.isError) {
                                    {
                                        val lastUser = messages.lastOrNull { it.role == "user" }
                                        if (lastUser != null) {
                                            onSendMessage(lastUser.content)
                                        }
                                    }
                                } else null
                            )
                        }
                    }
                }
            }
        }

        // Composer area
        Surface(
            color = DeepPanel,
            border = BorderStroke(1.dp, CyberBorder.copy(alpha = 0.6f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_prompt_input"),
                    placeholder = {
                        Text(
                            text = "Ask NINOH anything...",
                            color = TextTertiary
                        )
                    },
                    maxLines = 5,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CyberSurface,
                        unfocusedContainerColor = CyberSurface,
                        focusedBorderColor = CyanElectric,
                        unfocusedBorderColor = CyberBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                if (uiState.isStreamingChat) {
                    Surface(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onStopGeneration)
                            .testTag("stop_chat_button"),
                        color = CrimsonContainer,
                        border = BorderStroke(1.dp, CrimsonAlert),
                        shape = CircleShape
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop generating",
                                tint = CrimsonAlert
                            )
                        }
                    }
                } else {
                    val canSend = inputText.isNotBlank()
                    Surface(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .clickable(enabled = canSend) {
                                val text = inputText
                                inputText = ""
                                onSendMessage(text)
                            }
                            .testTag("send_chat_button"),
                        color = if (canSend) CyanElectric else CyberSurfaceElevated,
                        shape = CircleShape
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send prompt",
                                tint = if (canSend) Color(0xFF001F26) else TextTertiary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showRenameDialog && activeConversation != null) {
        RenameConversationDialog(
            currentTitle = activeConversation.title,
            onConfirm = { newTitle ->
                onRenameConversation(activeConversation.id, newTitle)
                showRenameDialog = false
            },
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showDeleteDialog && activeConversation != null) {
        DeleteConfirmationDialog(
            title = "Delete Conversation?",
            message = "This will permanently remove \"${activeConversation.title}\" and all its messages from your device.",
            onConfirm = {
                onDeleteConversation(activeConversation.id)
                showDeleteDialog = false
            },
            onDismiss = { showDeleteDialog = false }
        )
    }
}

@Composable
private fun ChatEmptyState(
    uiState: MainUiState,
    onOpenApiSettings: () -> Unit,
    onQuickPrompt: (String) -> Unit
) {
    val starters = listOf(
        "Compare REST vs GraphQL vs gRPC for mobile backends",
        "Explain Kotlin Coroutines StateFlow vs SharedFlow with examples",
        "Draft a clean Python script to parse and summarize JSON logs",
        "Review my API architecture and suggest caching improvements"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 560.dp),
                shape = RoundedCornerShape(20.dp),
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(132.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_ninoh_banner),
                            contentDescription = "NINOH AI neural network banner",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            CyberSurface.copy(alpha = 0.94f)
                                        )
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CyanContainer)
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = CyanElectric
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "NINOH API AGENT",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Multi-provider AI chat & engineering assistant",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyanElectric
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Active Endpoint",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary
                            )
                            Text(
                                text = "${uiState.activeProvider?.entity?.name ?: "None"} • ${uiState.settings.activeModelId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (uiState.activeProvider?.hasApiKey != true) {
            item {
                NoApiKeyCalloutCard(
                    providerName = uiState.activeProvider?.entity?.name ?: "OpenRouter",
                    onOpenSettings = onOpenApiSettings,
                    modifier = Modifier.widthIn(max = 560.dp)
                )
            }
        }

        item {
            Text(
                text = "QUICK LAUNCH PROMPTS",
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 560.dp)
                    .padding(top = 4.dp)
            )
        }

        items(starters) { prompt ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 560.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onQuickPrompt(prompt) },
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = VioletPulse,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun UserMessageBubble(message: MessageEntity) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 320.dp),
            shape = RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp),
            color = CyanContainer,
            border = BorderStroke(1.dp, CyanElectric.copy(alpha = 0.45f))
        ) {
            Text(
                text = message.content,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun AssistantMessageCard(
    message: MessageEntity,
    isStreaming: Boolean,
    onRetry: (() -> Unit)?
) {
    val clipboard = LocalClipboardManager.current
    var copiedAll by remember(message.content) { mutableStateOf(false) }

    LaunchedEffect(copiedAll) {
        if (copiedAll) {
            delay(1800)
            copiedAll = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp),
        color = if (message.isError) CrimsonContainer.copy(alpha = 0.55f) else CyberSurface,
        border = BorderStroke(
            1.dp,
            if (message.isError) CrimsonAlert.copy(alpha = 0.7f) else CyberBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (message.isError) Icons.Outlined.ErrorOutline else Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (message.isError) CrimsonAlert else CyanElectric,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = message.modelId?.substringAfterLast('/') ?: "NINOH",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (message.isError) CrimsonAlert else CyanElectric,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (message.latencyMs != null) {
                        Text(
                            text = "• ${message.latencyMs}ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary
                        )
                    }
                }

                if (isStreaming) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                        color = CyanElectric
                    )
                } else if (message.content.isNotBlank()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (onRetry != null) {
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(onClick = onRetry),
                                color = CyberSurfaceElevated,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Retry",
                                        tint = CyanElectric,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Retry",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanElectric
                                    )
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    clipboard.setText(AnnotatedString(message.content))
                                    copiedAll = true
                                }
                                .testTag("copy_response_button"),
                            color = CyberSurfaceElevated,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (copiedAll) Icons.Default.Check else Icons.Default.ContentCopy,
                                    contentDescription = "Copy response",
                                    tint = if (copiedAll) EmeraldOnline else TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (copiedAll) "Copied" else "Copy",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (copiedAll) EmeraldOnline else TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            if (message.content.isBlank() && isStreaming) {
                Text(
                    text = "Generating response...",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            } else {
                RichMessageContent(content = message.content)
            }
        }
    }
}
