package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MessageEntity
import com.example.domain.CodingLanguage
import com.example.domain.CodingTaskMode
import com.example.domain.MarkdownParser
import com.example.ui.components.NoApiKeyCalloutCard
import com.example.ui.components.ProviderStatusChip
import com.example.ui.components.RichMessageContent
import com.example.ui.theme.CodeBackground
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.DeepPanel
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.VioletContainer
import com.example.ui.theme.VioletPulse
import com.example.viewmodel.MainUiState
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodingScreen(
    uiState: MainUiState,
    messages: List<MessageEntity>,
    onOpenDrawer: () -> Unit,
    onOpenModelSelector: () -> Unit,
    onOpenApiSettings: () -> Unit,
    onNewCodingSession: () -> Unit,
    onSelectLanguage: (CodingLanguage) -> Unit,
    onSelectMode: (CodingTaskMode) -> Unit,
    onSubmitCodingRequest: (prompt: String, sourceCode: String) -> Unit,
    onStopGeneration: () -> Unit,
    modifier: Modifier = Modifier
) {
    var promptText by remember { mutableStateOf("") }
    var sourceCodeText by remember { mutableStateOf("") }
    var showCodeEditor by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .imePadding()
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepPanel,
                titleContentColor = TextPrimary
            ),
            navigationIcon = {
                IconButton(onClick = onOpenDrawer) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open navigation menu",
                        tint = TextPrimary
                    )
                }
            },
            title = {
                Column {
                    Text(
                        text = "Coding Studio",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "${uiState.selectedCodingLanguage.label} • ${uiState.selectedCodingMode.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = VioletPulse
                    )
                }
            },
            actions = {
                ProviderStatusChip(
                    providerItem = uiState.activeProvider,
                    modelId = uiState.settings.activeModelId,
                    onClick = onOpenModelSelector
                )
                IconButton(
                    onClick = {
                        promptText = ""
                        sourceCodeText = ""
                        onNewCodingSession()
                    },
                    modifier = Modifier.testTag("new_coding_session_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Coding Session",
                        tint = CyanElectric
                    )
                }
            }
        )

        // Language & Mode selector bar
        Surface(
            color = DeepPanel,
            border = BorderStroke(1.dp, CyberBorder.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CodingLanguage.entries.forEach { lang ->
                        val selected = lang == uiState.selectedCodingLanguage
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectLanguage(lang) }
                                .testTag("lang_chip_${lang.name.lowercase()}"),
                            color = if (selected) CyanContainer else CyberSurface,
                            border = BorderStroke(
                                1.dp,
                                if (selected) CyanElectric else CyberBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = lang.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) CyanElectric else TextSecondary,
                                modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CodingTaskMode.entries.forEach { mode ->
                        val selected = mode == uiState.selectedCodingMode
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectMode(mode) }
                                .testTag("mode_chip_${mode.name.lowercase()}"),
                            color = if (selected) VioletContainer else CyberSurface,
                            border = BorderStroke(
                                1.dp,
                                if (selected) VioletPulse else CyberBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = mode.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) Color(0xFFDCD0FF) else TextSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }

        // Main output stream
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uiState.activeProvider?.hasApiKey != true) {
                item(key = "coding_no_key") {
                    NoApiKeyCalloutCard(
                        providerName = uiState.activeProvider?.entity?.name ?: "your provider",
                        onOpenSettings = onOpenApiSettings
                    )
                }
            }

            if (messages.isEmpty()) {
                item(key = "coding_empty") {
                    CodingEmptyGuide(
                        language = uiState.selectedCodingLanguage,
                        mode = uiState.selectedCodingMode,
                        onSelectExample = { example ->
                            promptText = example
                        }
                    )
                }
            } else {
                items(messages, key = { it.id }) { msg ->
                    if (msg.role == "user") {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = CyberSurfaceElevated,
                            border = BorderStroke(1.dp, CyberBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "REQUEST",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VioletPulse
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                RichMessageContent(content = msg.content)
                            }
                        }
                    } else {
                        val isLast = msg.id == messages.lastOrNull()?.id
                        CodingOutputCard(
                            message = msg,
                            isStreaming = uiState.isStreamingCoding && isLast
                        )
                    }
                }
            }
        }

        // Bottom coding input & optional code context editor
        Surface(
            color = DeepPanel,
            border = BorderStroke(1.dp, CyberBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showCodeEditor = !showCodeEditor }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = CyanElectric,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (sourceCodeText.isBlank()) {
                                "Attach Existing Code (Optional)"
                            } else {
                                "Code Context Attached (${sourceCodeText.lines().size} lines)"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanElectric
                        )
                    }
                    Icon(
                        imageVector = if (showCodeEditor) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Toggle code editor",
                        tint = TextSecondary
                    )
                }

                AnimatedVisibility(visible = showCodeEditor) {
                    OutlinedTextField(
                        value = sourceCodeText,
                        onValueChange = { sourceCodeText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("coding_source_input"),
                        textStyle = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = TextPrimary
                        ),
                        placeholder = {
                            Text(
                                text = "Paste ${uiState.selectedCodingLanguage.label} code here to debug, refactor, or explain...",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextTertiary
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CodeBackground,
                            unfocusedContainerColor = CodeBackground,
                            focusedBorderColor = VioletPulse,
                            unfocusedBorderColor = CyberBorder
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = promptText,
                        onValueChange = { promptText = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("coding_prompt_input"),
                        maxLines = 4,
                        placeholder = {
                            Text(
                                text = "Describe what to build or fix in ${uiState.selectedCodingLanguage.label}...",
                                color = TextTertiary
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CyberSurface,
                            unfocusedContainerColor = CyberSurface,
                            focusedBorderColor = CyanElectric,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    if (uiState.isStreamingCoding) {
                        Button(
                            onClick = onStopGeneration,
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("stop_coding_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CrimsonContainer,
                                contentColor = CrimsonAlert
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop")
                        }
                    } else {
                        val enabled = promptText.isNotBlank() || sourceCodeText.isNotBlank()
                        Button(
                            onClick = {
                                val p = promptText
                                val c = sourceCodeText
                                promptText = ""
                                onSubmitCodingRequest(p, c)
                            },
                            enabled = enabled,
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("run_coding_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanElectric,
                                contentColor = Color(0xFF001F26)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Run Coding Agent")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CodingEmptyGuide(
    language: CodingLanguage,
    mode: CodingTaskMode,
    onSelectExample: (String) -> Unit
) {
    val examples = listOf(
        "Build a responsive navigation bar in HTML & CSS with smooth hover states",
        "Write an async JavaScript fetch wrapper with retry and timeout handling",
        "Create a Python FastAPI endpoint with Pydantic validation and error handling",
        "Implement a Kotlin StateFlow debounce search repository with Coroutines",
        "Write a memory-safe C++ LRU cache class with O(1) get and put"
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = CyberSurface,
            border = BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(VioletContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = VioletPulse
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "${language.label} • ${mode.label}",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = mode.instruction,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        Text(
            text = "CODING TEMPLATES",
            style = MaterialTheme.typography.labelSmall,
            color = TextTertiary,
            modifier = Modifier.padding(top = 4.dp)
        )

        examples.forEach { ex ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelectExample(ex) },
                color = CyberSurface,
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = ex,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun CodingOutputCard(
    message: MessageEntity,
    isStreaming: Boolean
) {
    val clipboard = LocalClipboardManager.current
    var copiedCode by remember(message.content) { mutableStateOf(false) }

    LaunchedEffect(copiedCode) {
        if (copiedCode) {
            delay(1800)
            copiedCode = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = if (message.isError) CrimsonContainer.copy(alpha = 0.55f) else CyberSurface,
        border = BorderStroke(
            1.dp,
            if (message.isError) CrimsonAlert.copy(alpha = 0.7f) else CyberBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = if (message.isError) CrimsonAlert else CyanElectric,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = message.modelId?.substringAfterLast('/') ?: "Coding Agent",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (message.isError) CrimsonAlert else CyanElectric,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (message.latencyMs != null) {
                        Text(
                            text = "• ${message.latencyMs}ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary
                        )
                    }
                }

                if (isStreaming) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                        color = CyanElectric
                    )
                } else if (message.content.isNotBlank() && !message.isError) {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                val extracted = MarkdownParser.extractAllCode(message.content)
                                clipboard.setText(AnnotatedString(extracted))
                                copiedCode = true
                            }
                            .testTag("copy_all_code_button"),
                        color = CyberSurfaceElevated,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (copiedCode) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "Copy all code",
                                tint = if (copiedCode) EmeraldOnline else CyanElectric,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (copiedCode) "Copied Code" else "Copy Code",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (copiedCode) EmeraldOnline else CyanElectric
                            )
                        }
                    }
                }
            }

            if (message.content.isBlank() && isStreaming) {
                Text(
                    text = "Writing ${message.codeLanguage ?: ""} code...",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            } else {
                RichMessageContent(content = message.content)
            }
        }
    }
}
