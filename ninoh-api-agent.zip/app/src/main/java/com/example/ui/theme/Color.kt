package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF07090F)
val DeepPanel = Color(0xFF0D121F)
val CyberSurface = Color(0xFF131B2E)
val CyberSurfaceElevated = Color(0xFF1A2540)
val CyberBorder = Color(0xFF253252)

val CyanElectric = Color(0xFF00E5FF)
val CyanMuted = Color(0xFF00B8D4)
val CyanContainer = Color(0xFF082D3A)

val VioletPulse = Color(0xFF8B5CF6)
val VioletContainer = Color(0xFF24194A)

val EmeraldOnline = Color(0xFF00E676)
val EmeraldContainer = Color(0xFF093220)

val AmberWarn = Color(0xFFFFB300)
val AmberContainer = Color(0xFF332404)

val CrimsonAlert = Color(0xFFFF5252)
val CrimsonContainer = Color(0xFF3B1016)

val TextPrimary = Color(0xFFF0F6FF)
val TextSecondary = Color(0xFF9BA8C4)
val TextTertiary = Color(0xFF647491)

val CodeBackground = Color(0xFF090D16)
val CodeHeaderBg = Color(0xFF111829)
val CodeKeyword = Color(0xFF7DD3FC)
val CodeString = Color(0xFF86EFAC)
val CodeComment = Color(0xFF64748B)
val CodeNumber = Color(0xFFFCA5A5)
val CodeType = Color(0xFFC4B5FD)
