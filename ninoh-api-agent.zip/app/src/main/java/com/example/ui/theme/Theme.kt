package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val NinohDarkColorScheme = darkColorScheme(
    primary = CyanElectric,
    onPrimary = Color(0xFF001F26),
    primaryContainer = CyanContainer,
    onPrimaryContainer = Color(0xFF9DF0FF),
    secondary = VioletPulse,
    onSecondary = Color(0xFFF5F3FF),
    secondaryContainer = VioletContainer,
    onSecondaryContainer = Color(0xFFDCD0FF),
    tertiary = EmeraldOnline,
    onTertiary = Color(0xFF00210E),
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = Color(0xFF98F7BE),
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = DeepPanel,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurface,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = ObsidianBg,
    surfaceContainerLow = DeepPanel,
    surfaceContainer = CyberSurface,
    surfaceContainerHigh = CyberSurfaceElevated,
    surfaceContainerHighest = Color(0xFF212E4F),
    outline = CyberBorder,
    outlineVariant = Color(0xFF1C2640),
    error = CrimsonAlert,
    onError = Color(0xFF2B0004),
    errorContainer = CrimsonContainer,
    onErrorContainer = Color(0xFFFFB4B4)
)

val NinohShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NinohAgentTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = false
                controller.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = NinohDarkColorScheme,
        typography = NinohTypography,
        shapes = NinohShapes,
        content = content
    )
}
