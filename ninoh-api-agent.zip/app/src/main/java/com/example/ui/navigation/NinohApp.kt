package com.example.ui.navigation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.local.ConversationEntity
import com.example.data.local.ConversationMode
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.QuickModelSelectorSheet
import com.example.ui.components.RenameConversationDialog
import com.example.ui.screens.ApiSettingsScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CodingScreen
import com.example.ui.screens.ModelsScreen
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.DeepPanel
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.VioletPulse
import com.example.viewmodel.MainUiState
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.launch

enum class NinohDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    CHAT("chat", "Chat", Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline),
    CODING("coding", "Coding", Icons.Filled.Code, Icons.Outlined.Code),
    MODELS("models", "Models", Icons.Filled.Memory, Icons.Outlined.Memory),
    SETTINGS("settings", "API", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun NinohApp(
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val codingMessages by viewModel.codingMessages.collectAsStateWithLifecycle()

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NinohDestination.CHAT.route

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var showQuickModelSheet by remember { mutableStateOf(false) }
    var conversationToRename by remember { mutableStateOf<ConversationEntity?>(null) }
    var conversationToDelete by remember { mutableStateOf<ConversationEntity?>(null) }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            NinohDrawerContent(
                uiState = uiState,
                currentRoute = currentRoute,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    navigateTo(route)
                },
                onNewChat = {
                    viewModel.startNewChat()
                    scope.launch { drawerState.close() }
                    navigateTo(NinohDestination.CHAT.route)
                },
                onSelectConversation = { conv ->
                    viewModel.openConversation(conv)
                    scope.launch { drawerState.close() }
                    val target = if (conv.mode == ConversationMode.CODING.name) {
                        NinohDestination.CODING.route
                    } else {
                        NinohDestination.CHAT.route
                    }
                    navigateTo(target)
                },
                onRequestRename = { conv -> conversationToRename = conv },
                onRequestDelete = { conv -> conversationToDelete = conv }
            )
        }
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = ObsidianBg,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = DeepPanel,
                            contentColor = TextPrimary,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            NinohDestination.entries.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    modifier = Modifier.testTag("nav_${dest.route}"),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = dest.label,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = CyanElectric,
                                        selectedTextColor = CyanElectric,
                                        indicatorColor = CyanContainer,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(
                            containerColor = DeepPanel,
                            contentColor = TextPrimary,
                            modifier = Modifier
                                .fillMaxHeight()
                                .windowInsetsPadding(WindowInsets.safeDrawing)
                        ) {
                            Spacer(modifier = Modifier.height(12.dp))
                            NinohDestination.entries.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = CyanElectric,
                                        selectedTextColor = CyanElectric,
                                        indicatorColor = CyanContainer,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    )
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = NinohDestination.CHAT.route,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(NinohDestination.CHAT.route) {
                            val activeConv = uiState.conversations.find { it.id == uiState.activeConversationId }
                            ChatScreen(
                                uiState = uiState,
                                messages = chatMessages,
                                activeConversation = activeConv,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onOpenModelSelector = { showQuickModelSheet = true },
                                onOpenApiSettings = { navigateTo(NinohDestination.SETTINGS.route) },
                                onNewChat = { viewModel.startNewChat() },
                                onRenameConversation = viewModel::renameConversation,
                                onDeleteConversation = viewModel::deleteConversation,
                                onSendMessage = viewModel::sendChatMessage,
                                onStopGeneration = viewModel::stopChatGeneration
                            )
                        }

                        composable(NinohDestination.CODING.route) {
                            CodingScreen(
                                uiState = uiState,
                                messages = codingMessages,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onOpenModelSelector = { showQuickModelSheet = true },
                                onOpenApiSettings = { navigateTo(NinohDestination.SETTINGS.route) },
                                onNewCodingSession = viewModel::startNewCodingSession,
                                onSelectLanguage = viewModel::setCodingLanguage,
                                onSelectMode = viewModel::setCodingMode,
                                onSubmitCodingRequest = viewModel::sendCodingRequest,
                                onStopGeneration = viewModel::stopCodingGeneration
                            )
                        }

                        composable(NinohDestination.MODELS.route) {
                            ModelsScreen(
                                uiState = uiState,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onFetchModels = viewModel::fetchModels,
                                onSelectModel = viewModel::selectModel,
                                onOpenApiSettings = { navigateTo(NinohDestination.SETTINGS.route) }
                            )
                        }

                        composable(NinohDestination.SETTINGS.route) {
                            ApiSettingsScreen(
                                uiState = uiState,
                                onOpenDrawer = { scope.launch { drawerState.open() } },
                                onSelectProvider = { viewModel.selectProvider(it.entity) },
                                onSaveProvider = viewModel::saveProviderConfig,
                                onTestConnection = viewModel::testProviderConnection,
                                onFetchModels = viewModel::fetchModels,
                                onDeleteProvider = viewModel::deleteProvider,
                                onClearApiKey = viewModel::clearApiKey,
                                onUpdateAgentParameters = viewModel::updateAgentParameters,
                                onClearFeedback = viewModel::clearFeedback
                            )
                        }
                    }
                }
            }
        }
    }

    if (showQuickModelSheet) {
        QuickModelSelectorSheet(
            providers = uiState.providers,
            activeProvider = uiState.activeProvider,
            activeModelId = uiState.settings.activeModelId,
            models = uiState.modelsForActiveProvider,
            isFetching = uiState.isFetchingModels,
            onSelectProvider = { viewModel.selectProvider(it.entity) },
            onSelectModel = viewModel::selectModel,
            onFetchModels = viewModel::fetchModels,
            onOpenSettings = { navigateTo(NinohDestination.SETTINGS.route) },
            onDismiss = { showQuickModelSheet = false }
        )
    }

    conversationToRename?.let { conv ->
        RenameConversationDialog(
            currentTitle = conv.title,
            onConfirm = { newTitle ->
                viewModel.renameConversation(conv.id, newTitle)
                conversationToRename = null
            },
            onDismiss = { conversationToRename = null }
        )
    }

    conversationToDelete?.let { conv ->
        DeleteConfirmationDialog(
            title = "Delete Conversation?",
            message = "Delete \"${conv.title}\" permanently from local history?",
            onConfirm = {
                viewModel.deleteConversation(conv.id)
                conversationToDelete = null
            },
            onDismiss = { conversationToDelete = null }
        )
    }
}

@Composable
private fun NinohDrawerContent(
    uiState: MainUiState,
    currentRoute: String,
    onNavigate: (String) -> Unit,
    onNewChat: () -> Unit,
    onSelectConversation: (ConversationEntity) -> Unit,
    onRequestRename: (ConversationEntity) -> Unit,
    onRequestDelete: (ConversationEntity) -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = DeepPanel,
        drawerContentColor = TextPrimary,
        modifier = Modifier.width(310.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            // Branding header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(104.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_ninoh_banner),
                    contentDescription = "NINOH header artwork",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.2f),
                                    DeepPanel.copy(alpha = 0.96f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "NINOH API AGENT",
                        style = MaterialTheme.typography.titleLarge,
                        color = CyanElectric
                    )
                    Text(
                        text = "AI Chat & Multi-Language Coding",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            // New Chat Button
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onNewChat)
                    .testTag("drawer_new_chat_button"),
                color = CyanContainer,
                border = BorderStroke(1.dp, CyanElectric.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AddComment,
                        contentDescription = null,
                        tint = CyanElectric,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "New Conversation",
                        style = MaterialTheme.typography.labelLarge,
                        color = CyanElectric
                    )
                }
            }

            // Navigation shortcuts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                NinohDestination.entries.forEach { dest ->
                    val selected = currentRoute == dest.route
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onNavigate(dest.route) },
                        color = if (selected) CyberSurfaceElevated else CyberSurface,
                        border = BorderStroke(1.dp, if (selected) CyanElectric else CyberBorder),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = dest.selectedIcon,
                                contentDescription = dest.label,
                                tint = if (selected) CyanElectric else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = dest.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) CyanElectric else TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = CyberBorder.copy(alpha = 0.6f))

            Text(
                text = "CONVERSATION HISTORY (${uiState.conversations.size})",
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (uiState.conversations.isEmpty()) {
                    item {
                        Text(
                            text = "Your chat and coding sessions will appear here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
                        )
                    }
                } else {
                    items(uiState.conversations, key = { it.id }) { conv ->
                        val isActive = conv.id == uiState.activeConversationId ||
                            conv.id == uiState.activeCodingConversationId
                        val isCoding = conv.mode == ConversationMode.CODING.name
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectConversation(conv) },
                            color = if (isActive) CyanContainer.copy(alpha = 0.45f) else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isCoding) Icons.Default.Code else Icons.Outlined.ChatBubbleOutline,
                                    contentDescription = null,
                                    tint = if (isCoding) VioletPulse else CyanElectric,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = conv.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isActive) TextPrimary else TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onRequestRename(conv) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Rename",
                                        tint = TextTertiary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onRequestDelete(conv) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = CrimsonAlert.copy(alpha = 0.85f),
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = CyberBorder.copy(alpha = 0.6f))
            // Active Provider Status Footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(NinohDestination.SETTINGS.route) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val hasKey = uiState.activeProvider?.hasApiKey == true
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(if (hasKey) EmeraldOnline else AmberWarn)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = uiState.activeProvider?.entity?.name ?: "No Provider",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = if (hasKey) uiState.settings.activeModelId else "Tap to configure API Key",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (hasKey) TextSecondary else AmberWarn,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
