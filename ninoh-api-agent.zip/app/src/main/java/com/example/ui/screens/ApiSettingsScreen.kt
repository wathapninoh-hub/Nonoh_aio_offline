package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ProviderPreset
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.DeepPanel
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.VioletPulse
import com.example.viewmodel.MainUiState
import com.example.viewmodel.ProviderUiItem
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiSettingsScreen(
    uiState: MainUiState,
    onOpenDrawer: () -> Unit,
    onSelectProvider: (ProviderUiItem) -> Unit,
    onSaveProvider: (
        providerId: String?,
        name: String,
        baseUrl: String,
        apiKey: String,
        defaultModelId: String,
        presetType: String,
        keepExistingKeyIfBlank: Boolean
    ) -> Unit,
    onTestConnection: (
        providerId: String?,
        name: String,
        baseUrl: String,
        apiKey: String,
        defaultModelId: String,
        presetType: String
    ) -> Unit,
    onFetchModels: () -> Unit,
    onDeleteProvider: (String) -> Unit,
    onClearApiKey: (String) -> Unit,
    onUpdateAgentParameters: (Float, Int, Boolean, String) -> Unit,
    onClearFeedback: () -> Unit,
    modifier: Modifier = Modifier
) {
    val active = uiState.activeProvider
    var editingProviderId by remember { mutableStateOf<String?>(active?.entity?.id) }
    var presetType by remember { mutableStateOf(active?.entity?.presetType ?: ProviderPreset.OPENROUTER.name) }
    var providerName by remember { mutableStateOf(active?.entity?.name ?: ProviderPreset.OPENROUTER.displayName) }
    var baseUrl by remember { mutableStateOf(active?.entity?.baseUrl ?: ProviderPreset.OPENROUTER.defaultBaseUrl) }
    var defaultModelId by remember { mutableStateOf(active?.entity?.defaultModelId ?: ProviderPreset.OPENROUTER.defaultModelId) }
    var apiKeyInput by remember { mutableStateOf("") }
    var showApiKey by remember { mutableStateOf(false) }

    var temperature by remember(uiState.settings.temperature) {
        mutableFloatStateOf(uiState.settings.temperature)
    }
    var maxTokens by remember(uiState.settings.maxTokens) {
        mutableIntStateOf(uiState.settings.maxTokens)
    }
    var streamResponses by remember(uiState.settings.streamResponses) {
        mutableStateOf(uiState.settings.streamResponses)
    }
    var systemPrompt by remember(uiState.settings.customSystemPrompt) {
        mutableStateOf(uiState.settings.customSystemPrompt)
    }

    LaunchedEffect(active?.entity?.id) {
        if (active != null) {
            editingProviderId = active.entity.id
            presetType = active.entity.presetType
            providerName = active.entity.name
            baseUrl = active.entity.baseUrl
            defaultModelId = active.entity.defaultModelId
            apiKeyInput = ""
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepPanel,
                titleContentColor = TextPrimary
            ),
            navigationIcon = {
                IconButton(onClick = onOpenDrawer) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open navigation menu",
                        tint = TextPrimary
                    )
                }
            },
            title = {
                Column {
                    Text(
                        text = "API Settings",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Encrypted Android Keystore storage",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldOnline
                    )
                }
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Security Assurance Banner
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = EmeraldContainer.copy(alpha = 0.45f),
                    border = BorderStroke(1.dp, EmeraldOnline.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = EmeraldOnline,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "API keys are encrypted locally on-device with AES-256-GCM and never logged or sent anywhere except your selected API endpoint.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Live Feedback Banner
            if (uiState.apiFeedback != null) {
                item {
                    val fb = uiState.apiFeedback
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = if (fb.isError) CrimsonContainer.copy(alpha = 0.7f) else EmeraldContainer.copy(alpha = 0.65f),
                        border = BorderStroke(1.dp, if (fb.isError) CrimsonAlert else EmeraldOnline)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (fb.isError) Icons.Outlined.ErrorOutline else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (fb.isError) CrimsonAlert else EmeraldOnline
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = fb.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = onClearFeedback) {
                                Text("Dismiss", color = TextSecondary)
                            }
                        }
                    }
                }
            }

            // Configured Providers List
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CONFIGURED PROVIDERS",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiary
                        )
                        TextButton(
                            onClick = {
                                editingProviderId = null
                                presetType = ProviderPreset.CUSTOM.name
                                providerName = "Custom Provider"
                                baseUrl = "https://api.openai.com/v1"
                                defaultModelId = "gpt-4o-mini"
                                apiKeyInput = ""
                                onClearFeedback()
                            },
                            modifier = Modifier.testTag("add_custom_provider_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = CyanElectric,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Custom Provider", color = CyanElectric)
                        }
                    }

                    uiState.providers.forEach { item ->
                        val isActive = item.entity.id == active?.entity?.id
                        val isEditing = item.entity.id == editingProviderId
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    onSelectProvider(item)
                                    editingProviderId = item.entity.id
                                    presetType = item.entity.presetType
                                    providerName = item.entity.name
                                    baseUrl = item.entity.baseUrl
                                    defaultModelId = item.entity.defaultModelId
                                    apiKeyInput = ""
                                    onClearFeedback()
                                }
                                .testTag("provider_card_${item.entity.id}"),
                            color = if (isActive || isEditing) CyanContainer.copy(alpha = 0.45f) else CyberSurface,
                            border = BorderStroke(
                                1.dp,
                                if (isActive) CyanElectric else CyberBorder
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                !item.hasApiKey -> AmberWarn
                                                item.entity.lastTestSuccess == false -> CrimsonAlert
                                                else -> EmeraldOnline
                                            }
                                        )
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.entity.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary
                                        )
                                        if (isActive) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = CyanElectric.copy(alpha = 0.16f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = "ACTIVE",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = CyanElectric,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = item.entity.baseUrl,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (item.hasApiKey) {
                                            "Key: ${item.maskedKey}" + (item.entity.lastTestLatencyMs?.let { " • ${it}ms" } ?: "")
                                        } else {
                                            "Key not configured"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (item.hasApiKey) EmeraldOnline else AmberWarn
                                    )
                                }

                                if (item.entity.presetType == ProviderPreset.CUSTOM.name && uiState.providers.size > 1) {
                                    IconButton(onClick = { onDeleteProvider(item.entity.id) }) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete provider",
                                            tint = CrimsonAlert
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Provider Configuration Form
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = CyberSurface,
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (editingProviderId == null) "Add Custom Provider" else "Configure $providerName",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )

                        // Preset template quick-fill chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ProviderPreset.entries.forEach { preset ->
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            val matchingExisting = uiState.providers.find { it.entity.id == preset.id }
                                            editingProviderId = matchingExisting?.entity?.id
                                            presetType = preset.name
                                            providerName = matchingExisting?.entity?.name ?: preset.displayName
                                            baseUrl = matchingExisting?.entity?.baseUrl ?: preset.defaultBaseUrl
                                            defaultModelId = matchingExisting?.entity?.defaultModelId ?: preset.defaultModelId
                                            apiKeyInput = ""
                                            matchingExisting?.let { onSelectProvider(it) }
                                        },
                                    color = if (presetType == preset.name) CyanContainer else CyberSurfaceElevated,
                                    border = BorderStroke(
                                        1.dp,
                                        if (presetType == preset.name) CyanElectric else CyberBorder
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = preset.displayName,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (presetType == preset.name) CyanElectric else TextSecondary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = providerName,
                            onValueChange = { providerName = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("provider_name_input"),
                            singleLine = true,
                            label = { Text("Provider Name") },
                            shape = RoundedCornerShape(12.dp),
                            colors = settingsTextFieldColors()
                        )

                        OutlinedTextField(
                            value = baseUrl,
                            onValueChange = { baseUrl = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("provider_base_url_input"),
                            singleLine = true,
                            label = { Text("API Base URL") },
                            placeholder = { Text("https://openrouter.ai/api/v1") },
                            shape = RoundedCornerShape(12.dp),
                            colors = settingsTextFieldColors()
                        )

                        val existingProvider = uiState.providers.find { it.entity.id == editingProviderId }
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = { apiKeyInput = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("provider_api_key_input"),
                            singleLine = true,
                            label = { Text("API Key") },
                            placeholder = {
                                Text(
                                    if (existingProvider?.hasApiKey == true) {
                                        "Saved (${existingProvider.maskedKey}) — enter to replace"
                                    } else {
                                        "Paste your API key (sk-...)"
                                    }
                                )
                            },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { showApiKey = !showApiKey }) {
                                    Icon(
                                        imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showApiKey) "Hide API Key" else "Show API Key"
                                    )
                                }
                            },
                            visualTransformation = if (showApiKey) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = settingsTextFieldColors()
                        )

                        AnimatedVisibility(visible = existingProvider?.hasApiKey == true) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = {
                                    editingProviderId?.let(onClearApiKey)
                                }) {
                                    Text("Remove Saved Key", color = CrimsonAlert)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = defaultModelId,
                            onValueChange = { defaultModelId = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("provider_model_id_input"),
                            singleLine = true,
                            label = { Text("Model ID") },
                            placeholder = { Text("e.g. openai/gpt-4o-mini") },
                            shape = RoundedCornerShape(12.dp),
                            colors = settingsTextFieldColors()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onSaveProvider(
                                        editingProviderId,
                                        providerName,
                                        baseUrl,
                                        apiKeyInput,
                                        defaultModelId,
                                        presetType,
                                        true
                                    )
                                    apiKeyInput = ""
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("save_provider_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyanElectric,
                                    contentColor = Color(0xFF001F26)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save")
                            }

                            OutlinedButton(
                                onClick = {
                                    onTestConnection(
                                        editingProviderId,
                                        providerName,
                                        baseUrl,
                                        apiKeyInput,
                                        defaultModelId,
                                        presetType
                                    )
                                },
                                enabled = !uiState.isTestingConnection,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("test_connection_button"),
                                border = BorderStroke(1.dp, VioletPulse),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (uiState.isTestingConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = VioletPulse
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Testing...", color = VioletPulse)
                                } else {
                                    Icon(
                                        Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = VioletPulse,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Test API", color = TextPrimary)
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = onFetchModels,
                            enabled = !uiState.isFetchingModels && existingProvider?.hasApiKey == true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("settings_fetch_models_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = null,
                                tint = CyanElectric,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (uiState.isFetchingModels) "Fetching Available Models..." else "Auto-Fetch Available Models",
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Agent Inference Parameters Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = CyberSurface,
                    border = BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Agent Parameters",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Live Token Streaming",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Stream responses token-by-token using SSE",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Switch(
                                checked = streamResponses,
                                onCheckedChange = { streamResponses = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF001F26),
                                    checkedTrackColor = CyanElectric
                                )
                            )
                        }

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Temperature",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary
                                )
                                Text(
                                    text = String.format("%.2f", temperature),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanElectric
                                )
                            }
                            Slider(
                                value = temperature,
                                onValueChange = { temperature = (it * 20).roundToInt() / 20f },
                                valueRange = 0f..1.5f,
                                colors = SliderDefaults.colors(
                                    thumbColor = CyanElectric,
                                    activeTrackColor = CyanElectric
                                )
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Max Output Tokens",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(1024, 2048, 4096, 8192, 16384).forEach { count ->
                                    val selected = maxTokens == count
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { maxTokens = count },
                                        color = if (selected) CyanContainer else CyberSurfaceElevated,
                                        border = BorderStroke(
                                            1.dp,
                                            if (selected) CyanElectric else CyberBorder
                                        ),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = "$count",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (selected) CyanElectric else TextSecondary,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = systemPrompt,
                            onValueChange = { systemPrompt = it },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3,
                            maxLines = 5,
                            label = { Text("System Prompt (Chat Mode)") },
                            shape = RoundedCornerShape(12.dp),
                            colors = settingsTextFieldColors()
                        )

                        Button(
                            onClick = {
                                onUpdateAgentParameters(
                                    temperature,
                                    maxTokens,
                                    streamResponses,
                                    systemPrompt
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("save_parameters_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VioletPulse,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Save Agent Parameters")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun settingsTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = CyberSurfaceElevated,
    unfocusedContainerColor = CyberSurfaceElevated,
    focusedBorderColor = CyanElectric,
    unfocusedBorderColor = CyberBorder,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary
)
