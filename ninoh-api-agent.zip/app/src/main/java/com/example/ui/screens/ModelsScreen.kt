package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedModelEntity
import com.example.ui.components.NoApiKeyCalloutCard
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.DeepPanel
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.VioletContainer
import com.example.ui.theme.VioletPulse
import com.example.viewmodel.MainUiState

private enum class ModelFilter(val label: String) {
    ALL("All"),
    CODE("Coding"),
    FREE("Free"),
    FAST("Fast / Mini")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(
    uiState: MainUiState,
    onOpenDrawer: () -> Unit,
    onFetchModels: () -> Unit,
    onSelectModel: (String) -> Unit,
    onOpenApiSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var activeFilter by remember { mutableStateOf(ModelFilter.ALL) }
    var customModelId by remember { mutableStateOf("") }

    val filteredModels = remember(uiState.modelsForActiveProvider, searchQuery, activeFilter) {
        uiState.modelsForActiveProvider.filter { model ->
            val matchesQuery = searchQuery.isBlank() ||
                model.modelId.contains(searchQuery, ignoreCase = true) ||
                model.displayName.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (activeFilter) {
                ModelFilter.ALL -> true
                ModelFilter.CODE -> model.modelId.contains("code", true) ||
                    model.modelId.contains("deepseek", true) ||
                    model.modelId.contains("qwen", true) ||
                    model.modelId.contains("claude", true)
                ModelFilter.FREE -> model.modelId.contains(":free", true) ||
                    model.displayName.contains("free", true)
                ModelFilter.FAST -> model.modelId.contains("mini", true) ||
                    model.modelId.contains("flash", true) ||
                    model.modelId.contains("8b", true) ||
                    model.modelId.contains("instant", true)
            }
            matchesQuery && matchesFilter
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepPanel,
                titleContentColor = TextPrimary
            ),
            navigationIcon = {
                IconButton(onClick = onOpenDrawer) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open navigation menu",
                        tint = TextPrimary
                    )
                }
            },
            title = {
                Column {
                    Text(
                        text = "AI Models",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = uiState.activeProvider?.entity?.name ?: "No Provider",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanElectric
                    )
                }
            },
            actions = {
                Button(
                    onClick = onFetchModels,
                    enabled = !uiState.isFetchingModels,
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .testTag("fetch_models_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanContainer,
                        contentColor = CyanElectric
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (uiState.isFetchingModels) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = CyanElectric
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Fetching...")
                    } else {
                        Icon(
                            imageVector = Icons.Default.CloudDownload,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Fetch Models")
                    }
                }
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uiState.activeProvider?.hasApiKey != true) {
                item {
                    NoApiKeyCalloutCard(
                        providerName = uiState.activeProvider?.entity?.name ?: "your provider",
                        onOpenSettings = onOpenApiSettings
                    )
                }
            }

            // Active Model Summary Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = CyberSurface,
                    border = BorderStroke(1.dp, CyanElectric.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyanContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = CyanElectric
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ACTIVE MODEL",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanElectric
                            )
                            Text(
                                text = uiState.settings.activeModelId.ifBlank { "None selected" },
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${uiState.modelsForActiveProvider.size} models cached for ${uiState.activeProvider?.entity?.name ?: "provider"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Manual custom model entry
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customModelId,
                        onValueChange = { customModelId = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("custom_model_id_input"),
                        singleLine = true,
                        label = { Text("Custom Model ID") },
                        placeholder = { Text("e.g. deepseek/deepseek-chat") },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CyberSurface,
                            unfocusedContainerColor = CyberSurface,
                            focusedBorderColor = CyanElectric,
                            unfocusedBorderColor = CyberBorder
                        )
                    )
                    Button(
                        onClick = {
                            if (customModelId.isNotBlank()) {
                                onSelectModel(customModelId.trim())
                                customModelId = ""
                            }
                        },
                        enabled = customModelId.isNotBlank(),
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .height(52.dp)
                            .testTag("apply_custom_model_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Select")
                    }
                }
            }

            if (uiState.modelsError != null) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = CrimsonContainer.copy(alpha = 0.6f),
                        border = BorderStroke(1.dp, CrimsonAlert)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ErrorOutline,
                                contentDescription = null,
                                tint = CrimsonAlert
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = uiState.modelsError,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Search & Filter controls
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("models_search_input"),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        placeholder = { Text("Search available models...") },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CyberSurface,
                            unfocusedContainerColor = CyberSurface,
                            focusedBorderColor = CyanElectric,
                            unfocusedBorderColor = CyberBorder
                        )
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ModelFilter.entries.forEach { filter ->
                            val selected = filter == activeFilter
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { activeFilter = filter },
                                color = if (selected) VioletContainer else CyberSurface,
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) VioletPulse else CyberBorder
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = filter.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color(0xFFDCD0FF) else TextSecondary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (filteredModels.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = CyberSurface,
                        border = BorderStroke(1.dp, CyberBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDownload,
                                contentDescription = null,
                                tint = CyanElectric,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = if (uiState.modelsForActiveProvider.isEmpty()) {
                                    "No models downloaded yet"
                                } else {
                                    "No matching models"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = if (uiState.modelsForActiveProvider.isEmpty()) {
                                    "Tap Fetch Models above to pull the live catalog from ${uiState.activeProvider?.entity?.name ?: "your provider"}."
                                } else {
                                    "Try clearing your search or switching filter chips."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            if (uiState.modelsForActiveProvider.isEmpty()) {
                                OutlinedButton(onClick = onFetchModels) {
                                    Text("Fetch Now")
                                }
                            }
                        }
                    }
                }
            } else {
                items(filteredModels, key = { it.compositeId }) { model ->
                    ModelListItemCard(
                        model = model,
                        isSelected = model.modelId == uiState.settings.activeModelId,
                        onSelect = { onSelectModel(model.modelId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ModelListItemCard(
    model: CachedModelEntity,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onSelect)
            .testTag("model_card_${model.modelId}"),
        color = if (isSelected) CyanContainer.copy(alpha = 0.6f) else CyberSurface,
        border = BorderStroke(1.dp, if (isSelected) CyanElectric else CyberBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = model.displayName,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = model.modelId,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSelected) CyanElectric else TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (model.contextLength != null && model.contextLength > 0) {
                        Surface(
                            color = CyberSurfaceElevated,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            val kCtx = model.contextLength / 1000
                            Text(
                                text = if (kCtx > 0) "${kCtx}K ctx" else "${model.contextLength} ctx",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (!model.ownedBy.isNullOrBlank()) {
                        Surface(
                            color = CyberSurfaceElevated,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = model.ownedBy,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(EmeraldOnline.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Active model",
                        tint = EmeraldOnline,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
