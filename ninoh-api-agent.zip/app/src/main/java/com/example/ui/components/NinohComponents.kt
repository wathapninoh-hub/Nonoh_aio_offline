package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CachedModelEntity
import com.example.domain.ContentSegment
import com.example.domain.MarkdownParser
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CodeBackground
import com.example.ui.theme.CodeHeaderBg
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.VioletPulse
import com.example.viewmodel.ProviderUiItem
import kotlinx.coroutines.delay

@Composable
fun CodeBlockCard(
    language: String,
    code: String,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    var copied by remember(code) { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1800)
            copied = false
        }
    }

    val highlighted = remember(code) { MarkdownParser.highlightCode(code) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, CyberBorder, RoundedCornerShape(14.dp)),
        color = CodeBackground
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CodeHeaderBg)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = CyanElectric,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = language.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanElectric
                    )
                }

                Surface(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            clipboard.setText(AnnotatedString(code))
                            copied = true
                        }
                        .testTag("copy_code_button"),
                    color = if (copied) Color(0xFF0A3321) else CyberSurfaceElevated,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AnimatedContent(targetState = copied, label = "copy_icon") { isCopied ->
                            Icon(
                                imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "Copy code",
                                tint = if (isCopied) EmeraldOnline else TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (copied) "Copied" else "Copy code",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (copied) EmeraldOnline else TextSecondary
                        )
                    }
                }
            }

            HorizontalDivider(color = CyberBorder.copy(alpha = 0.6f))

            SelectionContainer {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(14.dp)
                ) {
                    Text(
                        text = highlighted,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun RichMessageContent(
    content: String,
    modifier: Modifier = Modifier
) {
    val segments = remember(content) { MarkdownParser.parseSegments(content) }
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        segments.forEach { segment ->
            when (segment) {
                is ContentSegment.Text -> {
                    SelectionContainer {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            segment.markdown.lines().forEach { line ->
                                val trimmed = line.trimStart()
                                when {
                                    trimmed.startsWith("### ") -> {
                                        Text(
                                            text = MarkdownParser.formatInlineMarkdown(
                                                trimmed.removePrefix("### "),
                                                JetBrainsMonoFontFamily
                                            ),
                                            style = MaterialTheme.typography.titleSmall,
                                            color = CyanElectric,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                    trimmed.startsWith("## ") || trimmed.startsWith("# ") -> {
                                        val clean = trimmed.removePrefix("## ").removePrefix("# ")
                                        Text(
                                            text = MarkdownParser.formatInlineMarkdown(clean, JetBrainsMonoFontFamily),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TextPrimary,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                    trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                                        Row(modifier = Modifier.padding(start = 4.dp)) {
                                            Text(
                                                text = "• ",
                                                color = CyanElectric,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                text = MarkdownParser.formatInlineMarkdown(
                                                    trimmed.drop(2),
                                                    JetBrainsMonoFontFamily
                                                ),
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = TextPrimary
                                            )
                                        }
                                    }
                                    else -> {
                                        Text(
                                            text = MarkdownParser.formatInlineMarkdown(line, JetBrainsMonoFontFamily),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                is ContentSegment.CodeBlock -> {
                    CodeBlockCard(
                        language = segment.language,
                        code = segment.code
                    )
                }
            }
        }
    }
}

@Composable
fun NoApiKeyCalloutCard(
    providerName: String,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = CyberSurface,
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(listOf(AmberWarn.copy(alpha = 0.7f), CyanElectric.copy(alpha = 0.5f)))
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF332404)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = AmberWarn,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "API Key Required",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary
                )
                Text(
                    text = "Add your $providerName API key to start sending prompts.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onOpenSettings,
                modifier = Modifier.testTag("setup_api_key_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanElectric,
                    contentColor = Color(0xFF001F26)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Configure", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
fun ProviderStatusChip(
    providerItem: ProviderUiItem?,
    modelId: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasKey = providerItem?.hasApiKey == true
    val statusColor = when {
        !hasKey -> AmberWarn
        providerItem?.entity?.lastTestSuccess == false -> CrimsonAlert
        else -> EmeraldOnline
    }

    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("active_model_chip"),
        color = CyberSurfaceElevated,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = modelId.substringAfterLast('/').ifBlank { "Select Model" },
                style = MaterialTheme.typography.labelMedium,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(140.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickModelSelectorSheet(
    providers: List<ProviderUiItem>,
    activeProvider: ProviderUiItem?,
    activeModelId: String,
    models: List<CachedModelEntity>,
    isFetching: Boolean,
    onSelectProvider: (ProviderUiItem) -> Unit,
    onSelectModel: (String) -> Unit,
    onFetchModels: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var search by remember { mutableStateOf("") }
    var customModel by remember(activeModelId) { mutableStateOf("") }

    val filtered = remember(models, search) {
        if (search.isBlank()) models
        else models.filter {
            it.modelId.contains(search, ignoreCase = true) ||
                it.displayName.contains(search, ignoreCase = true)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberSurface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Switch Model & Provider",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Row {
                    IconButton(onClick = onFetchModels, enabled = !isFetching) {
                        if (isFetching) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = CyanElectric
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Fetch models",
                                tint = CyanElectric
                            )
                        }
                    }
                    IconButton(onClick = {
                        onDismiss()
                        onOpenSettings()
                    }) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "API Settings",
                            tint = TextSecondary
                        )
                    }
                }
            }

            // Provider switcher row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                providers.forEach { item ->
                    val selected = item.entity.id == activeProvider?.entity?.id
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectProvider(item) },
                        color = if (selected) CyanContainer else CyberSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (selected) CyanElectric else CyberBorder
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (item.hasApiKey) EmeraldOnline else AmberWarn)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = item.entity.name,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) CyanElectric else TextPrimary
                            )
                        }
                    }
                }
            }

            // Manual Model ID quick apply
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = customModel,
                    onValueChange = { customModel = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Enter custom Model ID...") },
                    shape = RoundedCornerShape(12.dp)
                )
                Button(
                    onClick = {
                        if (customModel.isNotBlank()) {
                            onSelectModel(customModel.trim())
                            onDismiss()
                        }
                    },
                    enabled = customModel.isNotBlank(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Use")
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Search ${models.size} fetched models...") },
                shape = RoundedCornerShape(12.dp)
            )

            if (filtered.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = CyberSurfaceElevated
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.WarningAmber,
                            contentDescription = null,
                            tint = AmberWarn
                        )
                        Text(
                            text = if (models.isEmpty()) {
                                "No models fetched yet for ${activeProvider?.entity?.name ?: "provider"}. Tap Refresh above after saving your API key."
                            } else {
                                "No models match \"$search\"."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filtered, key = { it.compositeId }) { model ->
                        val isSelected = model.modelId == activeModelId
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onSelectModel(model.modelId)
                                    onDismiss()
                                },
                            color = if (isSelected) CyanContainer.copy(alpha = 0.7f) else CyberSurfaceElevated,
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) CyanElectric else Color.Transparent
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = model.displayName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = model.modelId,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = CyanElectric,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RenameConversationDialog(
    currentTitle: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember(currentTitle) { mutableStateOf(currentTitle) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = { Text("Rename Conversation") },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                label = { Text("Conversation Title") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title) },
                enabled = title.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun DeleteConfirmationDialog(
    title: String,
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonAlert,
                    contentColor = Color.White
                )
            ) {
                Text("Delete")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
