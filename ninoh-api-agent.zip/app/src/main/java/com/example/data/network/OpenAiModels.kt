package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ChatMessageDto(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class ChatCompletionRequest(
    val model: String,
    val messages: List<ChatMessageDto>,
    val temperature: Double = 0.7,
    @Json(name = "max_tokens") val maxTokens: Int = 4096,
    val stream: Boolean = true
)

@JsonClass(generateAdapter = true)
data class ChatCompletionResponse(
    val id: String? = null,
    val choices: List<ChatChoiceDto>? = null,
    val error: ApiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class ChatChoiceDto(
    val index: Int? = null,
    val message: ChatMessageContentDto? = null,
    val delta: ChatDeltaDto? = null,
    @Json(name = "finish_reason") val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class ChatMessageContentDto(
    val role: String? = null,
    val content: String? = null
)

@JsonClass(generateAdapter = true)
data class ChatDeltaDto(
    val role: String? = null,
    val content: String? = null,
    @Json(name = "reasoning_content") val reasoningContent: String? = null
)

@JsonClass(generateAdapter = true)
data class StreamChunkDto(
    val id: String? = null,
    val choices: List<ChatChoiceDto>? = null,
    val error: ApiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class ModelsListResponse(
    val data: List<RemoteModelDto>? = null,
    val error: ApiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class RemoteModelDto(
    val id: String,
    val name: String? = null,
    @Json(name = "owned_by") val ownedBy: String? = null,
    @Json(name = "context_length") val contextLength: Int? = null,
    val description: String? = null
)

@JsonClass(generateAdapter = true)
data class ApiErrorEnvelope(
    val error: ApiErrorDetail? = null,
    val message: String? = null,
    val detail: String? = null
)

@JsonClass(generateAdapter = true)
data class ApiErrorDetail(
    val message: String? = null,
    val type: String? = null,
    val code: String? = null
)
