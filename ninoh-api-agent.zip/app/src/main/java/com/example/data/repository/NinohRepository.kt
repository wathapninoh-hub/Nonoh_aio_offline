package com.example.data.repository

import android.content.Context
import com.example.data.local.AgentSettings
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CachedModelEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.ConversationMode
import com.example.data.local.CredentialStorage
import com.example.data.local.MessageEntity
import com.example.data.local.ProviderEntity
import com.example.data.local.ProviderPreset
import com.example.data.local.SecureCredentialStorage
import com.example.data.network.ChatMessageDto
import com.example.data.network.ConnectionTestResult
import com.example.data.network.OpenAiCompatibleClient
import com.example.data.network.StreamEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID

class NinohRepository(
    context: Context,
    private val db: AppDatabase = AppDatabase.getInstance(context),
    private val credentials: CredentialStorage = SecureCredentialStorage(context),
    private val preferences: AppPreferences = AppPreferences(context),
    private val apiClient: OpenAiCompatibleClient = OpenAiCompatibleClient()
) {
    private val providerDao = db.providerDao()
    private val modelDao = db.cachedModelDao()
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()

    val providersFlow: Flow<List<ProviderEntity>> = providerDao.observeAll()
    val allModelsFlow: Flow<List<CachedModelEntity>> = modelDao.observeAll()
    val conversationsFlow: Flow<List<ConversationEntity>> = conversationDao.observeAll()
    val settingsFlow: Flow<AgentSettings> = preferences.settingsFlow

    fun observeModelsForProvider(providerId: String): Flow<List<CachedModelEntity>> =
        modelDao.observeForProvider(providerId)

    fun observeMessages(conversationId: String): Flow<List<MessageEntity>> =
        messageDao.observeForConversation(conversationId)

    suspend fun ensureDefaultPresetsSeeded() {
        val existing = providerDao.getAllOnce()
        if (existing.isEmpty()) {
            val now = System.currentTimeMillis()
            val defaults = listOf(
                ProviderPreset.OPENROUTER,
                ProviderPreset.GROQ,
                ProviderPreset.TOGETHER
            ).mapIndexed { index, preset ->
                ProviderEntity(
                    id = preset.id,
                    name = preset.displayName,
                    baseUrl = preset.defaultBaseUrl,
                    defaultModelId = preset.defaultModelId,
                    presetType = preset.name,
                    createdAt = now + index
                )
            }
            providerDao.insertAllIgnore(defaults)
        }
    }

    fun hasApiKey(providerId: String): Boolean = credentials.hasApiKey(providerId)

    fun getApiKey(providerId: String): String = credentials.getApiKey(providerId).orEmpty()

    fun getMaskedApiKey(providerId: String): String = credentials.getMaskedApiKey(providerId)

    suspend fun saveProviderConfig(
        provider: ProviderEntity,
        newApiKey: String?,
        setAsActive: Boolean = true
    ) {
        providerDao.upsert(provider)
        if (newApiKey != null) {
            if (newApiKey.isBlank()) {
                credentials.deleteApiKey(provider.id)
            } else {
                credentials.saveApiKey(provider.id, newApiKey)
            }
        }
        if (setAsActive) {
            preferences.setActiveProviderAndModel(provider.id, provider.defaultModelId)
        }
    }

    suspend fun deleteProvider(providerId: String) {
        credentials.deleteApiKey(providerId)
        modelDao.deleteForProvider(providerId)
        providerDao.deleteById(providerId)

        val remaining = providerDao.getAllOnce()
        val settings = preferences.settingsFlow.first()
        if (settings.activeProviderId == providerId && remaining.isNotEmpty()) {
            val next = remaining.first()
            preferences.setActiveProviderAndModel(next.id, next.defaultModelId)
        }
    }

    suspend fun selectActiveProvider(provider: ProviderEntity) {
        preferences.setActiveProviderAndModel(provider.id, provider.defaultModelId)
    }

    suspend fun selectActiveModel(providerId: String, modelId: String) {
        val provider = providerDao.getById(providerId)
        if (provider != null) {
            providerDao.upsert(provider.copy(defaultModelId = modelId))
        }
        preferences.setActiveProviderAndModel(providerId, modelId)
    }

    suspend fun updateAgentParameters(
        temperature: Float,
        maxTokens: Int,
        streamResponses: Boolean,
        customSystemPrompt: String
    ) {
        preferences.updateAgentParameters(
            temperature = temperature,
            maxTokens = maxTokens,
            streamResponses = streamResponses,
            customSystemPrompt = customSystemPrompt
        )
    }

    suspend fun testProviderConnection(
        provider: ProviderEntity,
        overrideApiKey: String? = null
    ): ConnectionTestResult {
        val key = overrideApiKey?.takeIf { it.isNotBlank() } ?: getApiKey(provider.id)
        val result = apiClient.testConnection(provider, key)
        providerDao.updateTestStatus(
            id = provider.id,
            success = result.success,
            message = result.message,
            latencyMs = result.latencyMs,
            testedAt = System.currentTimeMillis()
        )
        if (result.success && result.models.isNotEmpty()) {
            modelDao.deleteForProvider(provider.id)
            modelDao.insertAll(result.models)
        }
        return result
    }

    suspend fun fetchModelsForProvider(provider: ProviderEntity): Result<List<CachedModelEntity>> {
        val key = getApiKey(provider.id)
        val result = apiClient.fetchModels(provider, key)
        result.onSuccess { models ->
            modelDao.deleteForProvider(provider.id)
            if (models.isNotEmpty()) {
                modelDao.insertAll(models)
            }
        }
        return result
    }

    suspend fun createConversation(
        title: String,
        mode: ConversationMode,
        language: String? = null,
        providerId: String,
        modelId: String
    ): ConversationEntity {
        val now = System.currentTimeMillis()
        val conversation = ConversationEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            mode = mode.name,
            language = language,
            providerId = providerId,
            modelId = modelId,
            createdAt = now,
            updatedAt = now
        )
        conversationDao.upsert(conversation)
        return conversation
    }

    suspend fun renameConversation(conversationId: String, newTitle: String) {
        val clean = newTitle.trim()
        if (clean.isNotEmpty()) {
            conversationDao.rename(conversationId, clean, System.currentTimeMillis())
        }
    }

    suspend fun deleteConversation(conversationId: String) {
        conversationDao.deleteById(conversationId)
    }

    suspend fun addMessage(message: MessageEntity) {
        messageDao.upsert(message)
        val conv = conversationDao.getById(message.conversationId)
        if (conv != null) {
            conversationDao.update(conv.copy(updatedAt = message.timestamp))
        }
    }

    suspend fun updateMessageContent(
        messageId: String,
        content: String,
        isError: Boolean = false,
        latencyMs: Long? = null
    ) {
        messageDao.updateContent(messageId, content, isError, latencyMs)
    }

    suspend fun getConversationMessagesOnce(conversationId: String): List<MessageEntity> =
        messageDao.getForConversationOnce(conversationId)

    suspend fun updateConversationModel(
        conversationId: String,
        providerId: String,
        modelId: String
    ) {
        conversationDao.updateModel(conversationId, providerId, modelId, System.currentTimeMillis())
    }

    fun streamCompletion(
        provider: ProviderEntity,
        modelId: String,
        messages: List<ChatMessageDto>,
        temperature: Float,
        maxTokens: Int,
        stream: Boolean
    ): Flow<StreamEvent> {
        val apiKey = getApiKey(provider.id)
        return apiClient.streamChatCompletion(
            provider = provider,
            apiKey = apiKey,
            modelId = modelId,
            messages = messages,
            temperature = temperature,
            maxTokens = maxTokens,
            stream = stream
        )
    }
}
