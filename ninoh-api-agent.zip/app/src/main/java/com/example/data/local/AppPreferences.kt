package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.ninohDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "ninoh_agent_settings"
)

data class AgentSettings(
    val activeProviderId: String = AppPreferences.DEFAULT_PROVIDER_OPENROUTER,
    val activeModelId: String = AppPreferences.DEFAULT_MODEL_OPENROUTER,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 4096,
    val streamResponses: Boolean = true,
    val customSystemPrompt: String = AppPreferences.DEFAULT_SYSTEM_PROMPT
)

class AppPreferences(private val context: Context) {

    val settingsFlow: Flow<AgentSettings> = context.ninohDataStore.data.map { prefs ->
        AgentSettings(
            activeProviderId = prefs[KEY_ACTIVE_PROVIDER_ID] ?: DEFAULT_PROVIDER_OPENROUTER,
            activeModelId = prefs[KEY_ACTIVE_MODEL_ID] ?: DEFAULT_MODEL_OPENROUTER,
            temperature = (prefs[KEY_TEMPERATURE] ?: 0.7f).coerceIn(0f, 2f),
            maxTokens = (prefs[KEY_MAX_TOKENS] ?: 4096).coerceIn(256, 32768),
            streamResponses = prefs[KEY_STREAM_RESPONSES] ?: true,
            customSystemPrompt = prefs[KEY_SYSTEM_PROMPT] ?: DEFAULT_SYSTEM_PROMPT
        )
    }

    suspend fun setActiveProviderAndModel(providerId: String, modelId: String) {
        context.ninohDataStore.edit { prefs ->
            prefs[KEY_ACTIVE_PROVIDER_ID] = providerId
            prefs[KEY_ACTIVE_MODEL_ID] = modelId
        }
    }

    suspend fun setActiveModelId(modelId: String) {
        context.ninohDataStore.edit { prefs ->
            prefs[KEY_ACTIVE_MODEL_ID] = modelId
        }
    }

    suspend fun updateAgentParameters(
        temperature: Float,
        maxTokens: Int,
        streamResponses: Boolean,
        customSystemPrompt: String
    ) {
        context.ninohDataStore.edit { prefs ->
            prefs[KEY_TEMPERATURE] = temperature.coerceIn(0f, 2f)
            prefs[KEY_MAX_TOKENS] = maxTokens.coerceIn(256, 32768)
            prefs[KEY_STREAM_RESPONSES] = streamResponses
            prefs[KEY_SYSTEM_PROMPT] = customSystemPrompt.ifBlank { DEFAULT_SYSTEM_PROMPT }
        }
    }

    companion object {
        const val DEFAULT_PROVIDER_OPENROUTER = "preset_openrouter"
        const val DEFAULT_MODEL_OPENROUTER = "openai/gpt-4o-mini"
        const val DEFAULT_SYSTEM_PROMPT =
            "You are NINOH API AGENT, a sharp, reliable AI chat and software engineering assistant. Provide accurate, well-structured answers and clean, production-ready code inside fenced markdown code blocks."

        private val KEY_ACTIVE_PROVIDER_ID = stringPreferencesKey("active_provider_id")
        private val KEY_ACTIVE_MODEL_ID = stringPreferencesKey("active_model_id")
        private val KEY_TEMPERATURE = floatPreferencesKey("temperature")
        private val KEY_MAX_TOKENS = intPreferencesKey("max_tokens")
        private val KEY_STREAM_RESPONSES = booleanPreferencesKey("stream_responses")
        private val KEY_SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
    }
}
