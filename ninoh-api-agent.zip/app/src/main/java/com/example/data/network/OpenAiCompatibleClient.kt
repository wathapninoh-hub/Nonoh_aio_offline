package com.example.data.network

import com.example.data.local.CachedModelEntity
import com.example.data.local.ProviderEntity
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

sealed class StreamEvent {
    data class Delta(val chunk: String) : StreamEvent()
    data class Completed(val fullContent: String, val latencyMs: Long) : StreamEvent()
    data class Error(val message: String) : StreamEvent()
}

data class ConnectionTestResult(
    val success: Boolean,
    val message: String,
    val latencyMs: Long,
    val models: List<CachedModelEntity> = emptyList()
)

class OpenAiCompatibleClient {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val chatRequestAdapter = moshi.adapter(ChatCompletionRequest::class.java)
    private val chatResponseAdapter = moshi.adapter(ChatCompletionResponse::class.java)
    private val streamChunkAdapter = moshi.adapter(StreamChunkDto::class.java)
    private val modelsListAdapter = moshi.adapter(ModelsListResponse::class.java)
    private val errorEnvelopeAdapter = moshi.adapter(ApiErrorEnvelope::class.java)

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun fetchModels(
        provider: ProviderEntity,
        apiKey: String
    ): Result<List<CachedModelEntity>> = withContext(Dispatchers.IO) {
        val urlValidation = UrlNormalizer.validateAndNormalizeBaseUrl(provider.baseUrl)
        if (urlValidation is UrlNormalizer.ValidationResult.Invalid) {
            return@withContext Result.failure(IllegalArgumentException(urlValidation.reason))
        }
        val baseUrl = (urlValidation as UrlNormalizer.ValidationResult.Valid).normalizedBaseUrl
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("No API key configured for ${provider.name}. Enter your API key in API Settings.")
            )
        }

        val request = buildBaseRequest(
            url = UrlNormalizer.buildModelsUrl(baseUrl),
            apiKey = trimmedKey,
            baseUrl = baseUrl
        ).get().build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IOException(formatHttpError(response.code, bodyString, provider.name))
                    )
                }

                val parsed = runCatching { modelsListAdapter.fromJson(bodyString) }.getOrNull()
                if (parsed?.error?.message != null) {
                    return@withContext Result.failure(IOException(parsed.error.message))
                }

                val now = System.currentTimeMillis()
                val entities = parsed?.data.orEmpty()
                    .filter { it.id.isNotBlank() }
                    .distinctBy { it.id }
                    .map { dto ->
                        CachedModelEntity(
                            compositeId = "${provider.id}::${dto.id}",
                            providerId = provider.id,
                            modelId = dto.id,
                            displayName = dto.name?.takeIf { it.isNotBlank() } ?: dto.id,
                            contextLength = dto.contextLength,
                            ownedBy = dto.ownedBy,
                            description = dto.description,
                            fetchedAt = now
                        )
                    }
                    .sortedBy { it.displayName.lowercase() }

                Result.success(entities)
            }
        } catch (e: Exception) {
            Result.failure(IOException(formatException(e, provider.name)))
        }
    }

    suspend fun testConnection(
        provider: ProviderEntity,
        apiKey: String
    ): ConnectionTestResult = withContext(Dispatchers.IO) {
        val startMs = System.currentTimeMillis()
        val urlValidation = UrlNormalizer.validateAndNormalizeBaseUrl(provider.baseUrl)
        if (urlValidation is UrlNormalizer.ValidationResult.Invalid) {
            return@withContext ConnectionTestResult(
                success = false,
                message = urlValidation.reason,
                latencyMs = System.currentTimeMillis() - startMs
            )
        }
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            return@withContext ConnectionTestResult(
                success = false,
                message = "API Key is required to test ${provider.name}.",
                latencyMs = System.currentTimeMillis() - startMs
            )
        }

        val modelsResult = fetchModels(provider, trimmedKey)
        val elapsed = System.currentTimeMillis() - startMs
        modelsResult.fold(
            onSuccess = { models ->
                val msg = if (models.isNotEmpty()) {
                    "Connected to ${provider.name} (${models.size} models discovered in ${elapsed}ms)"
                } else {
                    "Connected to ${provider.name} (${elapsed}ms). Endpoint responded with 0 listed models; you can enter a custom Model ID."
                }
                ConnectionTestResult(
                    success = true,
                    message = msg,
                    latencyMs = elapsed,
                    models = models
                )
            },
            onFailure = { err ->
                // Some custom OpenAI-compatible gateways only implement /chat/completions and return 404/405 for /models
                val errMsg = err.message.orEmpty()
                if ((errMsg.contains("HTTP 404") || errMsg.contains("HTTP 405")) && provider.defaultModelId.isNotBlank()) {
                    pingChatEndpoint(provider, trimmedKey, startMs)
                } else {
                    ConnectionTestResult(
                        success = false,
                        message = errMsg.ifBlank { "Connection failed." },
                        latencyMs = elapsed
                    )
                }
            }
        )
    }

    private fun pingChatEndpoint(
        provider: ProviderEntity,
        apiKey: String,
        startMs: Long
    ): ConnectionTestResult {
        val baseUrl = (UrlNormalizer.validateAndNormalizeBaseUrl(provider.baseUrl)
            as UrlNormalizer.ValidationResult.Valid).normalizedBaseUrl
        val payload = ChatCompletionRequest(
            model = provider.defaultModelId.trim(),
            messages = listOf(ChatMessageDto(role = "user", content = "Reply with OK")),
            temperature = 0.0,
            maxTokens = 4,
            stream = false
        )
        val requestBody = chatRequestAdapter.toJson(payload).toRequestBody(jsonMediaType)
        val request = buildBaseRequest(
            url = UrlNormalizer.buildChatCompletionsUrl(baseUrl),
            apiKey = apiKey,
            baseUrl = baseUrl
        ).post(requestBody).build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                val elapsed = System.currentTimeMillis() - startMs
                val body = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    ConnectionTestResult(
                        success = true,
                        message = "Connected to ${provider.name} chat endpoint in ${elapsed}ms.",
                        latencyMs = elapsed
                    )
                } else {
                    ConnectionTestResult(
                        success = false,
                        message = formatHttpError(response.code, body, provider.name),
                        latencyMs = elapsed
                    )
                }
            }
        } catch (e: Exception) {
            ConnectionTestResult(
                success = false,
                message = formatException(e, provider.name),
                latencyMs = System.currentTimeMillis() - startMs
            )
        }
    }

    fun streamChatCompletion(
        provider: ProviderEntity,
        apiKey: String,
        modelId: String,
        messages: List<ChatMessageDto>,
        temperature: Float,
        maxTokens: Int,
        stream: Boolean
    ): Flow<StreamEvent> = callbackFlow {
        val startMs = System.currentTimeMillis()
        val urlValidation = UrlNormalizer.validateAndNormalizeBaseUrl(provider.baseUrl)
        if (urlValidation is UrlNormalizer.ValidationResult.Invalid) {
            trySend(StreamEvent.Error(urlValidation.reason))
            close()
            return@callbackFlow
        }
        val baseUrl = (urlValidation as UrlNormalizer.ValidationResult.Valid).normalizedBaseUrl
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            trySend(StreamEvent.Error("Missing API key for ${provider.name}. Configure your key in API Settings."))
            close()
            return@callbackFlow
        }
        if (modelId.isBlank()) {
            trySend(StreamEvent.Error("No model selected. Pick a model or enter a Model ID."))
            close()
            return@callbackFlow
        }

        val payload = ChatCompletionRequest(
            model = modelId.trim(),
            messages = messages,
            temperature = temperature.toDouble(),
            maxTokens = maxTokens,
            stream = stream
        )
        val jsonBody = chatRequestAdapter.toJson(payload)
        val request = buildBaseRequest(
            url = UrlNormalizer.buildChatCompletionsUrl(baseUrl),
            apiKey = trimmedKey,
            baseUrl = baseUrl
        )
            .header("Accept", if (stream) "text/event-stream, application/json" else "application/json")
            .post(jsonBody.toRequestBody(jsonMediaType))
            .build()

        val call = httpClient.newCall(request)
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string().orEmpty()
                    trySend(StreamEvent.Error(formatHttpError(response.code, errorBody, provider.name)))
                    close()
                    return@callbackFlow
                }

                val body = response.body
                if (body == null) {
                    trySend(StreamEvent.Error("${provider.name} returned an empty response body."))
                    close()
                    return@callbackFlow
                }

                val contentType = response.header("Content-Type").orEmpty().lowercase()
                val isEventStream = stream && contentType.contains("text/event-stream")

                if (isEventStream) {
                    val builder = StringBuilder()
                    val source = body.source()
                    while (!source.exhausted()) {
                        val line = source.readUtf8Line() ?: break
                        val trimmedLine = line.trim()
                        if (trimmedLine.isEmpty() || trimmedLine.startsWith(":")) continue

                        val dataPayload = if (trimmedLine.startsWith("data:")) {
                            trimmedLine.removePrefix("data:").trim()
                        } else {
                            continue
                        }

                        if (dataPayload == "[DONE]") {
                            break
                        }

                        val chunk = runCatching { streamChunkAdapter.fromJson(dataPayload) }.getOrNull()
                        if (chunk?.error?.message != null) {
                            trySend(StreamEvent.Error(chunk.error.message))
                            close()
                            return@callbackFlow
                        }

                        val deltaText = chunk?.choices
                            ?.firstOrNull()
                            ?.delta
                            ?.content
                        if (!deltaText.isNullOrEmpty()) {
                            builder.append(deltaText)
                            trySend(StreamEvent.Delta(deltaText))
                        }
                    }

                    val elapsed = System.currentTimeMillis() - startMs
                    val finalContent = builder.toString()
                    if (finalContent.isEmpty()) {
                        trySend(StreamEvent.Error("Model '$modelId' completed without returning any text."))
                    } else {
                        trySend(StreamEvent.Completed(finalContent, elapsed))
                    }
                } else {
                    val rawJson = body.string()
                    // Handle providers that send SSE lines even without text/event-stream content-type
                    if (rawJson.trimStart().startsWith("data:")) {
                        val builder = StringBuilder()
                        rawJson.lineSequence().forEach { line ->
                            val t = line.trim()
                            if (t.startsWith("data:")) {
                                val data = t.removePrefix("data:").trim()
                                if (data != "[DONE]") {
                                    val chunk = runCatching { streamChunkAdapter.fromJson(data) }.getOrNull()
                                    val delta = chunk?.choices?.firstOrNull()?.delta?.content
                                    if (!delta.isNullOrEmpty()) {
                                        builder.append(delta)
                                    }
                                }
                            }
                        }
                        val elapsed = System.currentTimeMillis() - startMs
                        val result = builder.toString()
                        if (result.isEmpty()) {
                            trySend(StreamEvent.Error("No text returned from $modelId."))
                        } else {
                            trySend(StreamEvent.Delta(result))
                            trySend(StreamEvent.Completed(result, elapsed))
                        }
                    } else {
                        val parsed = runCatching { chatResponseAdapter.fromJson(rawJson) }.getOrNull()
                        if (parsed?.error?.message != null) {
                            trySend(StreamEvent.Error(parsed.error.message))
                        } else {
                            val text = parsed?.choices?.firstOrNull()?.message?.content.orEmpty()
                            val elapsed = System.currentTimeMillis() - startMs
                            if (text.isBlank()) {
                                trySend(StreamEvent.Error("Model '$modelId' returned an empty message."))
                            } else {
                                trySend(StreamEvent.Delta(text))
                                trySend(StreamEvent.Completed(text, elapsed))
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (!call.isCanceled()) {
                trySend(StreamEvent.Error(formatException(e, provider.name)))
            }
        }
        close()
        awaitClose {
            call.cancel()
        }
    }.flowOn(Dispatchers.IO)

    private fun buildBaseRequest(url: String, apiKey: String, baseUrl: String): Request.Builder {
        val builder = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
        if (baseUrl.contains("openrouter.ai", ignoreCase = true)) {
            builder.header("HTTP-Referer", "https://ninoh.agent.app")
            builder.header("X-Title", "NINOH API AGENT")
        }
        return builder
    }

    private fun formatHttpError(code: Int, rawBody: String, providerName: String): String {
        val parsedMsg = runCatching {
            val env = errorEnvelopeAdapter.fromJson(rawBody)
            env?.error?.message ?: env?.message ?: env?.detail
        }.getOrNull()?.takeIf { it.isNotBlank() }

        val hint = when (code) {
            400 -> "Bad request (check Model ID and parameters)."
            401 -> "Authentication failed (invalid or expired API key)."
            402 -> "Insufficient credits or billing limit reached on $providerName."
            403 -> "Access forbidden (API key lacks permission for this model or endpoint)."
            404 -> "Endpoint or model not found (verify API Base URL and Model ID)."
            429 -> "Rate limit exceeded on $providerName. Wait a moment and retry."
            in 500..599 -> "$providerName server error (HTTP $code). Try again shortly."
            else -> "HTTP $code from $providerName."
        }

        return if (parsedMsg != null) {
            "HTTP $code — $hint\nDetails: $parsedMsg"
        } else {
            "HTTP $code — $hint"
        }
    }

    private fun formatException(e: Exception, providerName: String): String {
        return when (e) {
            is UnknownHostException -> "Cannot resolve host for $providerName. Check your internet connection and API Base URL."
            is SocketTimeoutException -> "Request to $providerName timed out. The model may be overloaded or unreachable."
            is ConnectException -> "Failed to connect to $providerName. Verify the Base URL and port."
            is SSLException -> "TLS/SSL handshake failed with $providerName. Verify the HTTPS URL."
            else -> e.message?.takeIf { it.isNotBlank() } ?: "Unexpected network error communicating with $providerName."
        }
    }
}
