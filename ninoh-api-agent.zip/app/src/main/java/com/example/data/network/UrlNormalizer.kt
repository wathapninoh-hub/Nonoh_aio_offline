package com.example.data.network

import java.net.URI

object UrlNormalizer {

    sealed class ValidationResult {
        data class Valid(val normalizedBaseUrl: String) : ValidationResult()
        data class Invalid(val reason: String) : ValidationResult()
    }

    fun validateAndNormalizeBaseUrl(rawUrl: String): ValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return ValidationResult.Invalid("API Base URL cannot be empty.")
        }

        val withScheme = if (!trimmed.contains("://")) {
            "https://$trimmed"
        } else {
            trimmed
        }

        val uri = try {
            URI(withScheme)
        } catch (e: Exception) {
            return ValidationResult.Invalid("Invalid URL format: ${e.message ?: "check syntax"}")
        }

        val scheme = uri.scheme?.lowercase()
        if (scheme != "https" && scheme != "http") {
            return ValidationResult.Invalid("Only https:// or http:// URLs are supported.")
        }

        val host = uri.host
        if (host.isNullOrBlank()) {
            return ValidationResult.Invalid("URL must include a valid domain or host.")
        }

        val isLoopback = host == "localhost" || host == "127.0.0.1" || host == "10.0.2.2"
        if (scheme == "http" && !isLoopback) {
            return ValidationResult.Invalid("Remote endpoints must use https:// (http:// is allowed only for localhost/10.0.2.2).")
        }

        var cleaned = withScheme.trimEnd('/')
        val suffixesToStrip = listOf("/chat/completions", "/models")
        for (suffix in suffixesToStrip) {
            if (cleaned.endsWith(suffix, ignoreCase = true)) {
                cleaned = cleaned.dropLast(suffix.length).trimEnd('/')
            }
        }

        return ValidationResult.Valid(cleaned)
    }

    fun buildModelsUrl(baseUrl: String): String {
        val clean = baseUrl.trim().trimEnd('/')
        return "$clean/models"
    }

    fun buildChatCompletionsUrl(baseUrl: String): String {
        val clean = baseUrl.trim().trimEnd('/')
        return if (clean.endsWith("/chat/completions", ignoreCase = true)) {
            clean
        } else {
            "$clean/chat/completions"
        }
    }
}
