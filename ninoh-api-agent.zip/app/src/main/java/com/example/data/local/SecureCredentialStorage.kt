package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

interface CredentialStorage {
    fun saveApiKey(providerId: String, apiKey: String)
    fun getApiKey(providerId: String): String?
    fun deleteApiKey(providerId: String)
    fun hasApiKey(providerId: String): Boolean
    fun getMaskedApiKey(providerId: String): String
}

class SecureCredentialStorage(context: Context) : CredentialStorage {

    private val prefs: SharedPreferences = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val keystoreAvailable: Boolean by lazy {
        try {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun saveApiKey(providerId: String, apiKey: String) {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) {
            deleteApiKey(providerId)
            return
        }
        val storedValue = if (keystoreAvailable) {
            encryptWithKeystore(trimmed)
        } else {
            // Fallback only used in local JVM/Robolectric unit tests where AndroidKeyStore is absent
            TEST_PREFIX + Base64.encodeToString(
                trimmed.toByteArray(StandardCharsets.UTF_8),
                Base64.NO_WRAP
            )
        }
        prefs.edit().putString(keyFor(providerId), storedValue).apply()
    }

    override fun getApiKey(providerId: String): String? {
        val encoded = prefs.getString(keyFor(providerId), null) ?: return null
        return try {
            if (encoded.startsWith(TEST_PREFIX) && !keystoreAvailable) {
                val raw = Base64.decode(encoded.removePrefix(TEST_PREFIX), Base64.NO_WRAP)
                String(raw, StandardCharsets.UTF_8)
            } else if (keystoreAvailable) {
                decryptWithKeystore(encoded)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    override fun deleteApiKey(providerId: String) {
        prefs.edit().remove(keyFor(providerId)).apply()
    }

    override fun hasApiKey(providerId: String): Boolean {
        return !getApiKey(providerId).isNullOrBlank()
    }

    override fun getMaskedApiKey(providerId: String): String {
        val key = getApiKey(providerId)?.trim() ?: return ""
        if (key.isEmpty()) return ""
        if (key.length <= 8) return "••••••••"
        val prefix = key.take(4)
        val suffix = key.takeLast(4)
        return "$prefix••••••••$suffix"
    }

    private fun encryptWithKeystore(plaintext: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        val ctB64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP)
        return "$ivB64:$ctB64"
    }

    private fun decryptWithKeystore(payload: String): String? {
        val parts = payload.split(":")
        if (parts.size != 2) return null
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), spec)
        val plainBytes = cipher.doFinal(ciphertext)
        return String(plainBytes, StandardCharsets.UTF_8)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun keyFor(providerId: String): String = "cred_${providerId}"

    companion object {
        private const val PREFS_NAME = "ninoh_secure_credentials"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "ninoh_api_key_master_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH = 128
        private const val TEST_PREFIX = "test_b64:"
    }
}
