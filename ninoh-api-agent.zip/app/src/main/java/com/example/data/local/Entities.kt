package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class ProviderPreset(
    val id: String,
    val displayName: String,
    val defaultBaseUrl: String,
    val defaultModelId: String,
    val description: String
) {
    OPENROUTER(
        id = "preset_openrouter",
        displayName = "OpenRouter",
        defaultBaseUrl = "https://openrouter.ai/api/v1",
        defaultModelId = "openai/gpt-4o-mini",
        description = "Unified gateway to 200+ models including Claude, GPT, Gemini & Llama"
    ),
    GROQ(
        id = "preset_groq",
        displayName = "Groq",
        defaultBaseUrl = "https://api.groq.com/openai/v1",
        defaultModelId = "llama-3.3-70b-versatile",
        description = "Ultra-low-latency LPU inference for Llama, DeepSeek & Qwen models"
    ),
    TOGETHER(
        id = "preset_together",
        displayName = "Together AI",
        defaultBaseUrl = "https://api.together.xyz/v1",
        defaultModelId = "meta-llama/Llama-3.3-70B-Instruct-Turbo",
        description = "High-throughput open-source models and specialized coding models"
    ),
    CUSTOM(
        id = "custom",
        displayName = "Custom OpenAI-Compatible",
        defaultBaseUrl = "https://api.openai.com/v1",
        defaultModelId = "gpt-4o-mini",
        description = "Any OpenAI-compatible REST endpoint (OpenAI, DeepSeek, Mistral, local proxy)"
    )
}

enum class ConversationMode {
    CHAT,
    CODING
}

@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val baseUrl: String,
    val defaultModelId: String,
    val presetType: String,
    val lastTestSuccess: Boolean? = null,
    val lastTestMessage: String? = null,
    val lastTestLatencyMs: Long? = null,
    val lastTestedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "cached_models",
    indices = [Index(value = ["providerId"])]
)
data class CachedModelEntity(
    @PrimaryKey val compositeId: String,
    val providerId: String,
    val modelId: String,
    val displayName: String,
    val contextLength: Int? = null,
    val ownedBy: String? = null,
    val description: String? = null,
    val fetchedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val mode: String = ConversationMode.CHAT.name,
    val language: String? = null,
    val providerId: String,
    val modelId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["conversationId"])]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val providerName: String? = null,
    val modelId: String? = null,
    val codeLanguage: String? = null,
    val isError: Boolean = false,
    val latencyMs: Long? = null,
    val timestamp: Long = System.currentTimeMillis()
)
