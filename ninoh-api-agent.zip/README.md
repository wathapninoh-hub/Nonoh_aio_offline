# NINOH API AGENT

A native Android AI Chat & Multi-Language Coding Agent built with **Kotlin** and **Jetpack Compose (Material 3)**. Connect directly to OpenAI-compatible AI providers using your own API keys stored securely on-device with Android Keystore AES-256-GCM encryption.

## Supported API Providers
- **OpenRouter** (`https://openrouter.ai/api/v1`)
- **Groq** (`https://api.groq.com/openai/v1`)
- **Together AI** (`https://api.together.xyz/v1`)
- **Custom OpenAI-Compatible Endpoints** (OpenAI, DeepSeek, Mistral, local Ollama/LM Studio proxies, or any `/chat/completions` + `/models` gateway)

All providers, API Base URLs, API Keys, and Model IDs are configured directly inside the **API Settings** screen—nothing is hardcoded.

## Key Features
- **AI Chat**: Persistent local conversation history, live SSE token streaming, stop/retry controls, copy response, rename/delete conversations, and navigation drawer history.
- **Coding Studio**: Dedicated coding assistant supporting HTML, CSS, JavaScript, Python, Java, Kotlin, C++, TypeScript, SQL, Rust, Go, and more—with syntax-highlighted code blocks and 1-tap code copying.
- **Models Browser**: Automatically fetches available models from `/models`, supports search & capability filters, and allows manual custom Model ID entry.
- **API Settings & Connection Tester**: Encrypted API key management, live API connection testing with latency measurement, and configurable temperature, max tokens, streaming toggle, and system prompt.

## Build Instructions

### Prerequisites
- Android Studio (Meerkat or newer) or JDK 17 + Android SDK (API 36)
- Gradle 9.3.1 (or use Android Studio's integrated Gradle runner)

### Build Locally (Command Line)
1. Clone or unzip the project directory.
2. Build the debug APK:
   ```bash
   gradle :app:assembleDebug
   ```
3. Locate the generated APK at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### Build via GitHub Actions
Push this repository to GitHub on `main` or `master` (or trigger **Actions -> Build NINOH API AGENT Debug APK -> Run workflow**).
The included `.github/workflows/build-debug-apk.yml` workflow compiles the project and produces a single downloadable artifact named **`NINOH-API-AGENT.apk`**.
